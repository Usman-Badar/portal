import React, { useEffect, useState } from 'react';
import './News.css';

import axios from '../../../../../axios';
import { useHistory } from 'react-router-dom';


import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const News = () => {

    const history = useHistory();
    const [ NewsPapers, setNewsPapers ] = useState([]);

    useEffect(
        () => {

            axios.get('/getallnewspapers').then( res => {

                setNewsPapers( res.data );

            } ).catch( err => {

                toast.dark( err , {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

            } );

        }, []
    );

    const GoToNewsPaper = ( id ) => {

        history.replace( '/news/newspaper/' + id );

    }

    return (
        <>
            <div className="Employee_Portal_news">
                {
                    NewsPapers.map(
                        ( val, index ) => {

                            return (
                                <div key={ index } onClick={ () => { GoToNewsPaper( val.id ) } } style={ { animationDelay: ( 0 + '.' + index ).toString() + 's' } }>
                                    <img src={ 'images/news_papers/' + val.news_papers_title_image } alt="news papers" />
                                </div>
                            )

                        }
                    )
                }
            </div>
        </>
    )
}
 export default News;