import React, { Suspense, useEffect, useState } from 'react'

import './Employee_Chat.css';
import axios from '../../../../../axios';

import { useSelector } from 'react-redux';
import $ from 'jquery';

import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Menu from '../../../../UI/Menu/Menu';
import Drives from './Components/ChatDrive';
import Modal from '../../../../UI/Modal/Modal';

import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css';

const Employee_Chat = () => {

    let key = 'real secret keys should be long and random';
    const encryptor = require('simple-encryptor')(key);

    const [ Employees, setEmployees ] = useState([]);
    const [ Chat, setChat ] = useState([]);
    const [ ChatEmployee, setChatEmployee ] = useState();
    const [ ModalShow, setModalShow ] = useState( false );
    const [ EmpID, setEmpID ] = useState();
    const [ EmpIndex, setEmpIndex ] = useState();
    const [ Drive, setDrive ] = useState([]);
    const [ Data, setData ] = useState([]);

    const [ EmpSearch, setEmpSearch ] = useState(
        {
            value: ''
        }
    );

    const [ ModalContent, setModalContent ] = useState();

    const [ ShowX, setShowX ] = useState(false);
    
    const searchcancle = ( e ) =>{
        setEmpSearch( { value: e.target.value } );
        if ( $('.Menusearch').val().length > 0 )
            {
                setShowX( true );
                OnSearch( e.target.value );
            }else
            {
                OnSearch( e.target.value );
                setShowX( false );
            }

    }
    const clickcross = () =>{
        setEmpSearch( { value: '' } );
        setShowX( false );
    }

    const CurrentEmployeeData = useSelector( ( state ) => state.EmpAuth.EmployeeData );

    useEffect(
        () => {
            
            cc();

            $('.PopupDiv').hide(0);
            GetAllEmployees('chat');
            setEmpID( parseInt( sessionStorage.getItem('EmpID') ) );

            setInterval(() => {
                $('.Grid2 .refresh').trigger('click');
            }, 1000);

            if (window.location.href.split('/').pop() === 'chat') {
                setData(
                    [
                        {
                            icon: 'las la-search',
                            txt: 'Search',
                            link: false,
                            func: () => ShowSearchBar()
                        },
                        {
                            icon: 'las la-users',
                            txt: 'Contacts',
                            link: false,
                            func: () => GetAllEmployees('contacts')
                        },
                        {
                            icon: 'lab la-rocketchat',
                            txt: 'Chat',
                            link: false,
                            func: () => GetAllEmployees('chat')
                        }
                    ]
                )
            }else {
                setData([]);
            }

            const Data = new FormData();
            Data.append('empID', sessionStorage.getItem('EmpID'));
            axios.post('/getemployeedrive', Data).then(res => {

                setDrive(res.data);
                setModalContent(<Drives Drive={ res.data } SelectItem={ DriveItemSelect } />);

            }).catch(err => {

                console.log(err);

            });

        }, []
    );

    const GetAllEmployees = ( mode ) => {
        const Data = new FormData();
        if ( mode === 'chat' )
        {
            setEmployees([]);
            $('.Grid2').hide();
            Data.append('currentEmp', sessionStorage.getItem('EmpID'));

            axios.post('/getchatemployees', Data).then(res => {

                setEmployees(res.data);

            }).catch(err => {

                toast.dark(err, {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

            });
        }

        if ( mode === 'contacts' )
        {
            setEmployees([]);
            $('.Grid2').hide();
            Data.append('currentEmp', sessionStorage.getItem('EmpID'));

            axios.post('/getallemployees', Data).then(res => {

                setEmployees(res.data);

            }).catch(err => {

                toast.dark(err, {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

            });
        }

    };

    const ShowHideChat = () => {

        if (window.location.href.split('/').pop() === 'chat' && $('.Employee_Chat').width() < 1000) {
            setData([]);
        }

        if ($('.Employee_Chat').width() < 1000){
            if( $('.Grid1').css('display') === 'none' )
            {
                $('.Grid1').show();
                $('.Grid2').hide();
            }else
            {
                $('.Grid1').hide();
                $('.Grid2').show();
            }
            
        }else
        {
            $('.Grid2').show();
        }

    }
    const GetThatEmpChat = ( id, index ) => {

        // setChatEmployee();
        // setEmpIndex();
        const Data = new FormData();
        Data.append('sender', id);
        Data.append('receiver', sessionStorage.getItem('EmpID'));
        axios.post('/getemployeewithchat', Data).then(res => {

            setChatEmployee( Employees[index] );
            setEmpIndex( index );
            if ( res.data.length > Chat.length || res.data.length < Chat.length )
            {
                setChat([]);
                setChat(res.data);
                var objDiv = document.getElementById("Chat_Box_Div");
                objDiv.scrollTop = objDiv.scrollHeight;
            }
            
            if ( $('.chat-box .msg-footer .input-group').find('i') )
            {
                // null
            }else
            {
                $('.chat-box .msg-footer .input-group').append("<div><button><i></i></button></div>");
                $('.chat-box .msg-footer .input-group button').addClass('btn').attr('type', 'button') ;
                $('.chat-box .msg-footer .input-group button i').addClass('lab la-google-drive');
            }

        }).catch(err => {

            toast.dark(err, {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

        });
        
    }

    const GoBack = () => {
        ShowHideChat();
        GetAllEmployees('chat');
        if (window.location.href.split('/').pop() === 'chat') {
            setData(
                [
                    {
                        icon: 'las la-search',
                        txt: 'Search',
                        link: false,
                        func: () => ShowSearchBar()
                    },
                    {
                        icon: 'las la-users',
                        txt: 'Contacts',
                        link: false,
                        func: () => GetAllEmployees('contacts')
                    },
                    {
                        icon: 'lab la-rocketchat',
                        txt: 'Chat',
                        link: false,
                        func: () => GetAllEmployees('chat')
                    }
                ]
            )
        }
    }

    const ShowSearchBar = () => {

        if ( !$('.Employee_Chat .Grid1 .searchbarDiv').hasClass('searchbarDivShow') )
        {
            $('.Employee_Chat .Grid1 .searchbarDiv').addClass('searchbarDivShow');
        }else
        {
            $('.Employee_Chat .Grid1 .searchbarDiv').removeClass('searchbarDivShow');
        }

    }

    const OnChat = ( e ) => {

        if ( e.keyCode === 13 )
        {
            const Data = new FormData();
            Data.append('eventID', 1);
            Data.append('senderID', sessionStorage.getItem('EmpID'));
            Data.append('receiverID', ChatEmployee.emp_id);
            Data.append('ChatBody', encryptor.encrypt(e.target.value));
            Data.append('NotificationBody', e.target.value);
            Data.append('Title', CurrentEmployeeData.name);
            axios.post('/insertchat', Data).then(() => {

                GetThatEmpChat(ChatEmployee.emp_id, EmpIndex);
                $('.Emp_Chat_2 .chatinput').val('');

                axios.post('/newnotification', Data).then(() => {
    
                }).catch(err => {
                    toast.dark(err, {
                        position: 'top-right',
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                });

            }).catch(err => {
                toast.dark(err, {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            });
        }

    }

    const OnSearch = ( val ) => {

        setEmployees([]);
        const Data = new FormData();
        Data.append('SearchKey', val);
        Data.append('currentEmp', sessionStorage.getItem('EmpID'));
        axios.post('/srchemp', Data).then( res => {

            setEmployees( res.data );

        } ).catch( err => {

            toast.dark( err , {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

        } );

    }

    const HideModelFunction = () => {
        let content = null;

        if (window.outerWidth < 992) {

            $('.Grid1').hide();
            $('.Grid2').hide();
            $('.PopupDiv').show();

            setData(
                [
                    {
                        icon: 'las la-undo',
                        txt: 'Back',
                        link: false,
                        func: () => HidePopUpDIv()
                    }
                ]
            )

            $('.Menu .Menu_Grid').css('z-index', '1000');
            $('.Menu .Menu_Speeddail').css('z-index', '1000');
            $('.Menu .Menu_Speeddail .Button').css('right', '30px');

        } else {
            if (ModalShow) {

                setModalShow(false);

            } else {

                content = <Drives Drive={ Drive } SelectItem={ DriveItemSelect } />
                setModalContent(content);
                setModalShow(true);
                
            }
        }
        
    }

    const HidePopUpDIv = () => {

        $('.Grid1').hide();
        $('.Grid2').show();
        $('.PopupDiv').hide();

        if ( window.outerWidth < 992 ) {
                
            setData(
                [
                ]
            )

        }else
        {   
            setData(
                [
                    {
                        icon: 'las la-search',
                        txt: 'Search',
                        link: false,
                        func: () => ShowSearchBar()
                    },
                    {
                        icon: 'las la-users',
                        txt: 'Contacts',
                        link: false,
                        func: () => GetAllEmployees('contacts')
                    },
                    {
                        icon: 'lab la-rocketchat',
                        txt: 'Chat',
                        link: false,
                        func: () => GetAllEmployees('chat')
                    }
                ]
            )
        }

    }

    const AttachDriveLink = () => {

        const Data = new FormData();
        Data.append('Attachements', sessionStorage.getItem('Drives'));
        Data.append('sender', sessionStorage.getItem('EmpID'));
        Data.append('receiver', ChatEmployee.emp_id);
        axios.post('/chatattachement', Data).then( res => {

            sessionStorage.setItem('Drives', '[]');
            $('.Emp_Chat_2 .chatinput').val(res.data);
            setModalShow(false);
                       

        } ).catch( err => {

            toast.dark(err, {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                });;

        } );

    }

    const DriveItemSelect = ( index, className ) => {

        if ( $('.' + className).hasClass('selected') )
        {

            $('.' + className).css('box-shadow', 'rgba(0, 0, 0, 0.16) 0px 1px 4px');
            $('.' + className).removeClass('selected');
            
            $('.Menu .Menu_Grid').css('z-index', 'unset');
            $('.Menu .Menu_Speeddail').css('z-index', 'unset');
            
            if ( sessionStorage.getItem('Drives') === undefined || sessionStorage.getItem('Drives') === '' || sessionStorage.getItem('Drives') === null )
            {
                // Don't do anything
            }else
            {
                let arr = JSON.parse( sessionStorage.getItem('Drives') );
                let newArr = arr.filter(
                    ( val ) => {

                        return val.id !== Drive[index].id

                    }
                )

                sessionStorage.setItem('Drives', JSON.stringify( newArr ));
            }

            if (JSON.parse(sessionStorage.getItem('Drives')).length === 0) {
                setData(
                    [
                        {
                            icon: 'las la-search',
                            txt: 'Search',
                            link: false,
                            func: () => ShowSearchBar()
                        },
                        {
                            icon: 'las la-users',
                            txt: 'Contacts',
                            link: false,
                            func: () => GetAllEmployees('contacts')
                        },
                        {
                            icon: 'lab la-rocketchat',
                            txt: 'Chat',
                            link: false,
                            func: () => GetAllEmployees('chat')
                        }
                    ]
                )
            }

            if ( window.outerWidth < 992 ) {

                if ( JSON.parse(sessionStorage.getItem('Drives')).length === 0 )
                {
                    setData(
                        [
                            {
                                icon: 'las la-undo',
                                txt: 'Back',
                                link: false,
                                func: () => HidePopUpDIv()
                            }
                        ]
                    )

                    $('.Menu .Menu_Grid').css('z-index', '1000');
                    $('.Menu .Menu_Speeddail').css('z-index', '1000');
                    $('.Menu .Menu_Speeddail .Button').css('right', '30px');
                }
    
            }

        }else
        {
            $('.' + className).css('box-shadow', 'rgb(13, 184, 222) 0px 1px 4px');
            $('.' + className).addClass('selected');
            
            if ( sessionStorage.getItem('Drives') === undefined || sessionStorage.getItem('Drives') === '' || sessionStorage.getItem('Drives') === null )
            {
                sessionStorage.setItem('Drives', JSON.stringify( [ Drive[index] ] ));
            }else
            {
                let arr = JSON.parse( sessionStorage.getItem('Drives') );
                arr.push( Drive[index] );

                sessionStorage.setItem('Drives', JSON.stringify( arr ));
            }
            
            if ( window.outerWidth < 992 ) {
                
                setData(
                    [
                        {
                            icon: 'las la-undo',
                            txt: 'Back',
                            link: false,
                            func: () => HidePopUpDIv()
                        },
                        {
                            icon: 'las la-paperclip',
                            txt: 'Attach',
                            link: false,
                            func: () => AttachDriveLink()
                        }
                    ]
                )
            }else
            {
                setData(
                    [
                        {
                            icon: 'las la-paperclip',
                            txt: 'Attach',
                            link: false,
                            func: () => AttachDriveLink()
                        }
                    ]
                )
            }

            
            $('.Menu .Menu_Grid').css('z-index', '1000');
            $('.Menu .Menu_Speeddail').css('z-index', '1000');
            $('.Menu .Menu_Speeddail .Button').css('right', '30px');

        }

    }

    const DownloadDrive = ( url ) => {

        let key = url.split('/').pop();
        const Data = new FormData();
        Data.append('Key', key);
        axios.post('/downloaddrive', Data).then(res => {

            if ( res.data === 'NOT FOUND' )
            {
                alert('DRIVE HAS BEEN EXPIRED OR YOU DO NOT HAVE PERMISSION TO ACCESS');
            }else
            {
                for ( let x= 0; x < res.data[1].length; x++ )
                {
    
                    let link = document.createElement("a");
                    // If you don't know the name or want to use
                    // the webserver default set name = ''
                    link.setAttribute('download', 'images/drive/' + res.data[1][x].name);
                    link.href = 'images/drive/' + res.data[1][x].name;
                    document.body.appendChild(link);
                    link.click();
                    link.remove();
    
                }
            }

        }).catch(err => {

            console.log(err);

        })

    }

    let content = <SkeletonTheme baseColor="#fff" highlightColor="#ECF0F5">
                    <Skeleton style={ { padding: '8px 0', margin: '5px 0', borderRadius: '30px' } } count={30} />
                </SkeletonTheme>

    const cc = () => {

        setTimeout(() => {
            $('.Employee_Chat .Grid1 .list .listContent').html("<h4>No Chat Yet</h4>");
        }, 1000);

    }

    return (
        <>
            <Menu data={ Data } />
            <div className="Employee_Chat">
                <div className="PopupDiv">
                    <Drives Drive={ Drive } SelectItem={ DriveItemSelect } />
                </div>
                <div className="Grid1">
                    <div className="DIV1 searchbarDiv">
                        <input type="text" value={EmpSearch.value} placeholder="Search Keywords" className="form-control Menusearch" onChange={searchcancle} />
                        {
                            !ShowX
                                ?
                                <i className="las la-search"></i>
                                :
                                <i className="las la-times" onClick={clickcross}></i>
                        }
                    </div>
                    <div className="list">
                        <Suspense fallback={ content }>
                            {
                                Employees.length === 0
                                ?
                                    <div className="listContent text-center">{ content }</div>
                                :
                                Employees.map(
                                    (val, index) => {

                                        return (
                                            <>
                                                {
                                                    val.emp_id === parseInt( sessionStorage.getItem('EmpID') )
                                                    ?
                                                        null
                                                    :
                                                        <div onClick={ ShowHideChat }>
                                                            <div className="DIV1 d-flex emplist" style={ { animationDelay: ( 0 + '.' + index ).toString() + 's' } } onClick={() => GetThatEmpChat(val.emp_id, index)}>
                                                                <div className="d-flex align-items-center">
                                                                    <img src={'images/employees/' + val.emp_image} alt="DP" className="empImgs" />
                                                                </div>
                                                                <div className="d-flex align-items-center w-100">
                                                                    <div>
                                                                        <p className="font-weight-bold">{val.name}</p>
                                                                        <p> {val.designation_name + " at " + val.location_name + ", " + val.company_name} </p>
                                                                    </div>
                                                                </div>
                                                                {/* <div>
                                                                    <span>1</span>
                                                                </div> */}
                                                            </div>
                                                        </div>
                                                }
                                            </>
                                        )

                                    }
                                )
                            }
                        </Suspense>
                    </div>
                </div>
                <div className="Grid2">
                    {
                        ChatEmployee !== undefined
                        ?
                            <>
                                <div className="Emp_Chat_2">
                                    <div className="Emp_Chat_Div">
                                        <div className="d-flex Emp_Chat_Header px-3 py-2">
                                            <div className="mr-3"><img src={ 'images/employees/' + ChatEmployee.emp_image } onClick={ GoBack } alt="employee Img" /></div>
                                            <div>
                                                <div className="d-block" style={ { fontSize: '12px' } }>
                                                    <p className="font-weight-bolder mb-0"> { ChatEmployee.name } </p>
                                                    <p> { ChatEmployee.designation_name } at { ChatEmployee.location_name }, { ChatEmployee.company_name } </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="Chat_Box_Div" id="Chat_Box_Div">
                                            {
                                                Chat.map(
                                                    ( val, index ) => {

                                                        return (
                                                            <>
                                                                {
                                                                    val.sender_id !== EmpID
                                                                    ?
                                                                        <>
                                                                        {/* <p className="text-center"> { d } </p> */}
                                                                        <div className="Chat_Box_Container_left"><img src={ 'images/employees/' + ChatEmployee.emp_image } alt="dp" className="mr-1" />
                                                                            <div style={ { animationDelay: ( 0 + '.' + index ).toString() + 's' } } className="Chat_Box_Message">
                                                                                <p style={ { cursor: encryptor.decrypt(val.chat_body).toString().substring(0,5) === 'https' ? 'pointer' : null } } onClick={ () => encryptor.decrypt(val.chat_body) ? encryptor.decrypt(val.chat_body).toString().substring(0,5) === 'https' ? DownloadDrive( encryptor.decrypt(val.chat_body).toString().split('===').shift() ) : null : null }> { encryptor.decrypt(val.chat_body) } </p>
                                                                                <div className="d-flex justify-content-end align-items-center" style={{ fontSize: '12px' }}>
                                                                                    <p>{ ( val.send_date ? val.send_date.substring(0,10) : null ) + ' at ' + val.send_time }</p></div>
                                                                            </div>
                                                                        </div>
                                                                        </>
                                                                    :
                                                                        <div style={ { animationDelay: ( 0 + '.' + index ).toString() + 's' } } className="Chat_Box_Container_right">
                                                                            <div style={ { animationDelay: ( 0 + '.' + index ).toString() + 's' } } className="Chat_Box_Message">
                                                                                <p style={ { cursor: encryptor.decrypt(val.chat_body).toString().substring(0,5) === 'https' ? 'pointer' : null } } onClick={ () => encryptor.decrypt(val.chat_body) ? encryptor.decrypt(val.chat_body).toString().substring(0,5) === 'https' ? DownloadDrive( encryptor.decrypt(val.chat_body).toString().split('===').shift() ) : null : null }> { encryptor.decrypt(val.chat_body) } </p>
                                                                                <div className="d-flex justify-content-end align-items-center" style={{ fontSize: '12px' }}>
                                                                                    <p>{ ( val.send_date ? val.send_date.substring(0,10) : null ) + ' at ' + val.send_time }</p>{ val.read_status === 'Read' ? <i className="las la-check-double ml-1"></i> : <i className="las la-check ml-1"></i> }</div>
                                                                            </div><img src={ 'images/employees/' + CurrentEmployeeData.emp_image } alt="dp" className="ml-1" /></div>
                                                                }
                                                            </>
                                                        )

                                                    }
                                                )
                                            }
                                        </div>
                                        <div className="d-flex TextAreaDiv" style={ { height: 'max-content', border: '1px solid lightgray' } }>
                                            <div className="w-100">
                                                <input
                                                    className="form-control chatinput"
                                                    onKeyDown={OnChat}
                                                    style={{ width: "100%", height: "50px" }}
                                                    required
                                                />
                                            </div>
                                            <div className="p-1 d-flex align-items-center" style={{ fontSize: "25px" }}>
                                                <div id="Button" onClick={HideModelFunction}>
                                                    <i class="lab la-google-drive"></i>
                                                </div>

                                                <button className="btn text-white refresh d-none" onClick={() => GetThatEmpChat(ChatEmployee.emp_id, EmpIndex)}><i className="las la-redo-alt"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </>
                        :
                        null
                    }
                    <Modal show={ ModalShow } Hide={ HideModelFunction } content={ModalContent} />
                </div>
            </div>
        </>
    )
}
 export default Employee_Chat;