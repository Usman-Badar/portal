const express = require('express');
const router = express.Router();
const db = require('../../db/connection');

router.post('/deviceinout', ( req, res ) => {

    const { EmpID, date, time, location } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "INSERT INTO emp_machine_thumbs (emp_id, date, time, location, status) VALUES (?,?,?,?,?)",
                    [ EmpID, date, time, location, 'Waiting' ],
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/getempinout', ( req, res ) => {

    const { location } = req.body;

    const d = new Date();

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT * FROM emp_machine_thumbs WHERE location = '" + location + "' AND status = 'Waiting' AND date= '" + d.getFullYear() + '-' + parseInt(d.getMonth() + 1) + '-' + d.getDate() + "' GROUP BY id ASC LIMIT 1",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
                            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/getempinoutsdetails', ( req, res ) => {

    const { empID } = req.body;


    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT DISTINCT emp_machine_thumbs.date, COUNT(emp_machine_thumbs.emp_id) AS inouts FROM emp_machine_thumbs WHERE emp_machine_thumbs.emp_id = " + empID,
                    ( err, rslt ) => {
            
                        if( err )
                        {
                            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

module.exports = router;