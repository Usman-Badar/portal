const express = require('express');
const router = express.Router();
const db = require('../../db/connection');

router.post('/timein', ( req, res ) => {

    const { empID } = req.body;
    const d = new Date();

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {

                connection.query(
                    'SELECT time_in FROM emp_attendance WHERE emp_id = ' + empID + ' AND emp_date = ?',
                    [ d ],
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            console.log( err );
            
                        }else 
                        {
                            
                            if ( !rslt[0] )
                            {
                                connection.query(
                                    'SELECT time_in, time_out FROM employees WHERE emp_id = ' + empID,
                                    ( err, rslt ) => {
                            
                                        if( err )
                                        {
                            
                                            connection.release();
                                            res.send( err );
                            
                                        }else 
                                        {
                                            
                                            let time1 = rslt[0].time_in.substring(3, 5);
                                            let time2 = d.toTimeString();
                                            time1 = parseInt(time1) + 16;
                                            time1 = rslt[0].time_in.substring(0, 3) + time1.toString() + ':00';
                            
                                            let status = 'Present';
                                            
                                            if ( time2 > time1 )
                                            {
                                                status = 'Late';
                                            }
                            
                                            connection.query(
                                                'INSERT IGNORE INTO emp_attendance (emp_id, status, time_in, emp_date) VALUES (?,?,?,?)',
                                                [ empID, status, d.toTimeString(), d ],
                                                ( err, rslt ) => {
                                        
                                                    if( err )
                                                    {
                                        
                                                        connection.release();
                                                        console.log( err );
                                        
                                                    }else 
                                                    {
                                                        
                                                        connection.release();
                                                        res.send( 'success' );
                                        
                                                    }
                                        
                                                }
                                            )
                            
                                        }
                            
                                    }
                                )
                            }
            
                        }
            
                    }
                )
                
            }

        }
    )

} );

router.post('/timeout', ( req, res ) => {

    const { empID } = req.body;
    const d = new Date();

    
    db.getConnection(
        ( err, connection ) => {
            
            if ( err )
            {
                
                
                res.send([]);
                
            }else
            {

                connection.query(
                    "UPDATE emp_attendance SET time_out = '" + d.toTimeString() + "' WHERE emp_id = " + empID + " AND emp_attendance.emp_date = '" + d.getFullYear() + '-' + ( parseInt(d.getMonth() + 1).toString().length === 1 ? '0' + parseInt(d.getMonth() + 1).toString() : parseInt(d.getMonth() + 1).toString() ) + '-' + ( d.getDate().toString().length === 1 ? '0' + d.getDate().toString() : d.getDate() ) + "'",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            res.send( 'success' );
                            connection.release();
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/breakin', ( req, res ) => {

    const { empID } = req.body;
    const d = new Date();


    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "UPDATE emp_attendance SET break_in = '" + d.toTimeString() + "' WHERE emp_id = " + empID + " AND emp_attendance.emp_date = '" + d.getFullYear() + '-' + ( parseInt(d.getMonth() + 1).toString().length === 1 ? '0' + parseInt(d.getMonth() + 1).toString() : parseInt(d.getMonth() + 1).toString() ) + '-' + ( d.getDate().toString().length === 1 ? '0' + d.getDate().toString() : d.getDate() ) + "'",
                    ( err, rslt ) => {
            
                        if( err )
                        {

                            connection.release();
                            res.send( err );
            
                        }else 
                        {

                            connection.release();
                            res.send( 'success' );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/breakout', ( req, res ) => {

    const { empID } = req.body;
    const d = new Date();

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "UPDATE emp_attendance SET break_out = '" + d.toTimeString() + "' WHERE emp_id = " + empID + " AND emp_attendance.emp_date = '" + d.getFullYear() + '-' + ( parseInt(d.getMonth() + 1).toString().length === 1 ? '0' + parseInt(d.getMonth() + 1).toString() : parseInt(d.getMonth() + 1).toString() ) + '-' + ( d.getDate().toString().length === 1 ? '0' + d.getDate().toString() : d.getDate() ) + "'",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( 'success' );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/setstatustolog', ( req, res ) => {

    const { empID } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "UPDATE emp_machine_thumbs SET status = 'valid' WHERE status = 'Waiting' AND emp_id = " + empID,
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( 'success' );
            
                        }
            
                    }
                )
            }

        }
    )

} );

module.exports = router;