const express = require('express');
const router = express.Router();
const db = require('../../db/connection');

router.get('/getallattdevices', ( req, res ) => {
    
    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT att_devices.*, locations.location_name FROM locations LEFT OUTER JOIN att_devices ON locations.location_code = att_devices.location_code WHERE locations.attendance_mode = 'tablet'",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/setattdevice', ( req, res ) => {

    const { DevName, DevLocation, DevCode } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "INSERT INTO att_devices ( location_code, device_name, device_code ) VALUES (?,?,?)",
                    [ DevLocation, DevName, DevCode ],
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/getattdevicebylocation', ( req, res ) => {

    const { DevLocation } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT * FROM att_devices WHERE location_code = " + DevLocation,
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/getattdevicebycode', ( req, res ) => {

    const { DevLocation } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT * FROM att_devices WHERE device_code = '" + DevLocation + "'",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

module.exports = router;