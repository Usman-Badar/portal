const express = require('express');
const router = express.Router();
const db = require('../../db/connection');

router.post('/getallmeetableemployees', ( req, res ) => {

    const { location } = req.body;
    
    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT emp_app_profile.emp_image, employees.emp_id, employees.name, employees.department_code, employees.designation_code FROM employees \
                    RIGHT OUTER JOIN emp_app_profile ON employees.emp_id = emp_app_profile.emp_id \
                    RIGHT OUTER JOIN departments ON departments.department_code = employees.department_code \
                    RIGHT OUTER JOIN designations ON designations.designation_code = employees.designation_code \
                    WHERE employees.location_code = " + location + " AND employees.guest_meetable != 0;",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/GetGuestOnKeyWord', ( req, res ) => {

    const { Column, key } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT * FROM guests \
                    WHERE " + Column + " LIKE '%" + key + "%';",
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send( rslt );
            
                        }
            
                    }
                )
            }

        }
    )

} );

router.post('/getallregisteredguestslocationwise', ( req, res ) => {

    const { location } = req.body;

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "SELECT employees.name AS meeting_person, guests.* FROM guests LEFT OUTER JOIN employees ON guests.emp_id = employees.emp_id WHERE guests.location_code = " + location + " GROUP BY id DESC",
                    (err, rslt) => {

                        if (err) {

                            connection.release();
                            res.send(err);

                        } else {

                            connection.release();
                            res.send(rslt);

                        }

                    }
                )
            }

        }
    )

} );

router.post('/registerguest', ( req, res ) => {

    const { GuestName, GuestPhone, MeetingWith, MeetingTime, location, GstImgName } = req.body;
    const { GstImg } = req.files;
    
    let imgName = GstImgName + '.png';

    const d = new Date();
    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "INSERT INTO guests (guest_image, guest_name, guest_phone) VALUES (?,?,?)",
                    [ imgName, GuestName, GuestPhone ],
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            GstImg.mv('client/public/images/guests/' + imgName, (err) => {
            
                                if (err) {

                                    connection.release();
                                    res.send( err );
                        
                                }else
                                {
                                    connection.query(
                                        "SELECT id FROM guests WHERE guest_phone = '" + GuestPhone + "' AND guest_name = '" + GuestName + "'",
                                        ( err, rslt ) => {
                                
                                            if( err )
                                            {
                                
                                                connection.release();
                                                res.send( err );
                                
                                            }else 
                                            {
                                
                                                connection.query(
                                                    "INSERT INTO guest_meetings (guest_id, emp_id, location_code, meeting_time, meeting_date) VALUES (?,?,?,?,?)",
                                                    [ rslt[0].id, MeetingWith, location, MeetingTime, d ],
                                                    ( err, rslt ) => {
                                            
                                                        if( err )
                                                        {
                                            
                                                            connection.release();
                                                            res.send( err );
                                            
                                                        }else 
                                                        {
                                            
                                                            connection.release();
                                                            res.send('Done');
                                            
                                                        }
                                            
                                                    }
                                                );
                                
                                            }
                                
                                        }
                                    );
                                }
                        
                            });
            
                        }
            
                    }
                );
            }

        }
    )

} );

router.post('/registerguest2', ( req, res ) => {

    const { GuestID, MeetingWith, MeetingTime, location } = req.body;

    const d = new Date();

    db.getConnection(
        ( err, connection ) => {

            if ( err )
            {

                
                res.send([]);

            }else
            {
                connection.query(
                    "INSERT INTO guest_meetings (guest_id, emp_id, location_code, meeting_time, meeting_date) VALUES (?,?,?,?,?)",
                    [ GuestID, MeetingWith, location, MeetingTime, d ],
                    ( err, rslt ) => {
            
                        if( err )
                        {
            
                            connection.release();
                            res.send( err );
            
                        }else 
                        {
            
                            connection.release();
                            res.send('Done');
            
                        }
            
                    }
                );
            }

        }
    )

} );

module.exports = router;