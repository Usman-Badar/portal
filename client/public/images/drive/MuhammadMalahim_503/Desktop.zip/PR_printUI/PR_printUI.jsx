import React, { useEffect } from "react";
import './PR_printUI.css';
import QFS from './Logos/QFS-LOGO.PNG';
import SBS from './Logos/SEABOARD-SERVICES.PNG';
import SBL from './Logos/SBL-LOGO.PNG';
import axios from "axios";

const PR_printUI = () => {

    const ListDetails = [
        {
            Sno: '01',
            desc: 'Laptop',
            Quantity: '01',
            EstimatedCost: '50000',
            TotalCost: '50000',
            Reason: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is',
        },
        {
            Sno: '02',
            desc: 'Pen',
            Quantity: '05',
            EstimatedCost: '25',
            TotalCost: '125',
            Reason: 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is',
        }
    ]


    useEffect(
        () => {
            
            axios.get('https://192.168.100.120:8080/createpdf').then(
                ( res ) => {

                    console.log( res.data );

                }
            ).catch( err => {

                console.log( err );

            } )

            const Data = new FormData();
            Data.append('Arr', JSON.stringify(ListDetails))
            axios.post('https://192.168.100.120:8080/createpdfs/', Data).then(
                ( res ) => {

                    console.log( res.data );

                }
            ).catch( err => {

                console.log( err );

            } )

        }, []
    )

    return (
        <>
            <div className="PR_printUI">
                <div className="PR_printUI_Div">
                    <h1 className=" font-weight-bolder text-center">Seaboard Group</h1>
                    <div className="PR_printUI_Logos">
                        <div><img src={QFS} alt="QFS Logo" /></div>
                        <div><img src={SBS} alt="SBS Logo" /></div>
                        <div><img src={SBL} alt="SBL Logo" /></div>
                    </div>
                    <h3 className="font-weight-bolder text-center" >Purchase Requisition</h3>
                    <div className="PR_printUI_Top mt-5">
                        <div>
                            <div className="d-flex">
                                <p className="font-weight-bolder mr-3">Comapny Name : </p>
                                <p>Seaboard Services</p>
                            </div>
                            <div className="d-flex">
                                <p className="font-weight-bolder mr-3">Delivery / Work Location : </p>
                                <p>Headoffice</p>
                            </div>
                        </div>
                        <div className="w-25">
                            <div className="d-flex border py-1">
                                <div className="border-right w-50 text-center"><p className="font-weight-bolder">PR Number  </p></div>
                                <div className="text-center w-50"><p>0123456789</p></div>
                            </div>
                            <div className="d-flex border py-1">
                                <div className="border-right w-50 text-center"><p className="font-weight-bolder">Date  </p></div>
                                <div className="text-center w-50"><p>2021-10-20</p></div>
                            </div>
                        </div>
                    </div>
                    <div className="PR_printUI_Middle">
                        <div className="PR_printUI_Grid" style={{ backgroundColor: "rgb(243, 243, 243)" }}>
                            <div><p className="font-weight-bolder">Sr: No:</p></div>
                            <div><p className="font-weight-bolder">Description</p></div>
                            <div><p className="font-weight-bolder">Quantity</p></div>
                            <div><p className="font-weight-bolder" >Estimated Cost</p></div>
                            <div><p className="font-weight-bolder">Total Cost</p></div>
                        </div>
                        {
                            ListDetails.map(
                                (val, index) => {
                                    return (
                                        <>
                                            <div className="PR_printUI_Grid">
                                                <div><p>{val.Sno}</p></div>
                                                <div><p>{val.desc}</p></div>
                                                <div><p>{val.Quantity}</p></div>
                                                <div><p>{val.EstimatedCost}</p></div>
                                                <div><p>{val.TotalCost}</p></div>
                                            </div>
                                        </>
                                    )
                                }
                            )
                        }
                        <div className="PR_printUI_Grid">
                            <div></div>
                            <div style={{ backgroundColor: "rgb(243, 243, 243)" }}><p className="font-weight-bolder text-right mr-2">Total :</p></div>
                            <div><p></p></div>
                            <div><p></p></div>
                            <div><p>Rs 50125</p></div>
                        </div>
                    </div>
                    <div className="PR_printUI_Bottom">
                        <div className="PR_printUI_Grid1" style={{ backgroundColor: "rgb(243, 243, 243)" }}>
                            <div><p className="font-weight-bolder">Sr: No:</p></div>
                            <div><p className="font-weight-bolder">Reason</p></div>
                        </div>
                        {
                            ListDetails.map(
                                (val, index) => {
                                    return (
                                        <>
                                            <div className="PR_printUI_Grid1">
                                                <div><p>{val.Sno}</p></div>
                                                <div className="text-justify px-2"><p>{val.Reason}</p></div>
                                            </div>
                                        </>
                                    )
                                }
                            )
                        }
                        <div className="PR_printUI_Remarks mt-4" style={{ backgroundColor: "rgb(243, 243, 243)" }}>
                            <div className="DIVS" ><p className="font-weight-bolder">Sumbitted By</p></div>
                            <div className="DIVS" ><p className="font-weight-bolder">Approved By</p></div>
                            <div className="DIVS" ><p className="font-weight-bolder">Submitted To</p></div>
                        </div>
                        <div className="PR_printUI_Remarks PR_printUI_Remark">
                            <div >
                                <div className="DIVS" ><p className="font-weight-bolder mr-3">Name : </p><p>Malahim</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Date : </p><p>2021-20-20</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Signature : </p><div></div></div>
                            </div>
                            <div >
                                <div className="DIVS" ><p className="font-weight-bolder mr-3">Name : </p><p>Salman Panjwani</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Date : </p><p>2021-20-21</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Signature : </p><div></div></div>
                            </div>
                            <div >
                                <div className="DIVS" ><p className="font-weight-bolder mr-3">Name : </p><p>Antash Javaid</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Date : </p><p>2021-20-22</p></div>
                                <div className="DIVS" ><p className="font-weight-bolder">Signature : </p><div></div></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default PR_printUI;