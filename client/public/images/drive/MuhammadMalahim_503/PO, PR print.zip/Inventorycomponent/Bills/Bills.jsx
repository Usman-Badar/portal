import React, { useEffect, useState } from "react";
import './Bills.css';

import axios from "axios";

const Bills = () => {

    const [Bills, setBills] = useState([]);

    
    useEffect(
        () => {

            let po_id = window.location.href.split('/').pop(); // RETURNS AN ID ( PO ID ) FROM THE URL

            axios.post(
                'https://192.168.10.116:8888/getpurchaseorderdetails',
                {
                    po_id: po_id,
                    pr_id: null
                }
            ).then(
                (res) => {

                    console.log( res.data )
                    setBills( res.data[2] );

                }
            ).catch(err => {

                console.log(err);

            })

        }, []
    )

    return (
        <>
            {
                Bills.map(
                    (val) => {
                        return (
                            <>
                                <div className="Bills">
                                    <div><img src={ 'images/Inventory/po_attachments/' + val.Bills } alt="Bills" /></div>
                                </div>
                            </>
                        )
                    }
                )
            }
        </>
    )
}
export default Bills;