import React from 'react';
import './FormWithADPayments.css';
const FormWithADPayments = ( props ) => {
    const ariaLabel = { 'aria-label': 'description', minLength: 3 };
    return (
        <>
            <div className="FormWithADPayments">
            <h4 className="mb-3 font-weight-bolder">{ props.heading }</h4>
                <form onSubmit={ props.AddContent }>
                    <div className="mb-3">
                        <p className="font-weight-bolder mb-2 ">Advance Receiver's Name</p>
                        <input className="form-control" placeholder="Placeholder" value={  props.AD.receiver } onChange={ props.onChangeHandler } name='receiver' inputProps={ariaLabel} style={{ width: "100%" }} required />
                    </div>
                    <div className="mb-3">
                        <p className="font-weight-bolder mb-2">Amount</p>
                        <input
                            className="form-control"
                            id="standard-number"
                            type="number"
                            style={{ width: "100%" }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            inputProps={
                                {
                                    min: 1
                                }
                            }
                            variant="standard"
                            onChange={ props.onChangeHandler }
                            name='amount'
                            required
                            value={ props.AD.amount}

                        />
                    </div>
                    <div className="mb-3">
                        <p className="font-weight-bolder mb-2">Reason</p>
                        <textarea
                            className="form-control"
                            id="textarea"
                            aria-label="minimum height"
                            minRows={3}
                            placeholder="Describe the Reason"
                            style={{ width: "100%" }}
                            onChange={props.onChangeHandler}
                            name='reason'
                            required
                            minLength="20"
                            value={props.heading === 'Advance Payments', props.AD.reason }
                        ></textarea>
                    </div>
                    <div className="d-flex justify-content-right">
                        <button variant="text" className="mr-3 btn" onClick={props.showHide} style={ {color: 'black'} }>Cancel</button>
                        <button type="submit" variant="contained" className="btn" id="Submit"style={ {backgroundColor: 'black', color: 'white'} } >Attach</button>
                    </div>
                </form>
            </div>
        </>
    )
}
export default FormWithADPayments;