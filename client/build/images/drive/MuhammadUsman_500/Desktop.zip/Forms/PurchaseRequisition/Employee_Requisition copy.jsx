import React, { useEffect, useState } from 'react';
import './Employee_Requisition.css';

import Menu from '../../../../../UI/Menu/Menu';
import axios from '../../../../../../axios';

import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import SpecificationForm from './Component/SpecificationForm/SpecificationForm';

import $ from 'jquery';

const Employee_Requisition = () => {

    const [ Specifications, setSpecifications ] = useState(
        {
            desc: '',
            quantity: 0,
            amount: 0,
            reason: ''
        }
    );

    const [ AllSpecifications, setAllSpecifications ] = useState([]);
    const [ Total, setTotal ] = useState(0.00);

    const [ ShowSpForm, setShowSpForm ] = useState( false );
    const [ ShowSpecifications, setShowSpecifications ] = useState( false );
    const [ ShowPrForm, setShowPrForm ] = useState( false );

    const [ Locations, setLocations ] = useState([]);
    const [ Data, setData ] = useState([]);

    useEffect(
        () => {

            axios.get('/getalllocations').then(res => {

                setLocations(res.data);

                setData(
                    [
                        {
                            icon: 'las la-money-check-alt',
                            txt: 'Add Specification',
                            link: false, // || true
                            func: () => ShowUI(0)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'All Specifications',
                            link: false, // || true
                            func: () => ShowUI(1)
                        }
                    ]
                )

            }).catch(err => {

                toast.dark(err.toString(), {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

            });

            setShowPrForm( true );

        }, []

    )

    const ShowUI = ( mode ) => {

        if ( mode === 0 )
        {
            if ( ShowSpForm )
            {
                setShowSpForm( false );
            }else
            {
                setShowSpForm( true );

                setShowSpecifications( false );
                setShowPrForm( false );

                setData(
                    [
                        {
                            icon: 'las la-money-check-alt',
                            txt: 'Add Specification',
                            link: false, // || true
                            func: () => ShowUI(0)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'All Specifications',
                            link: false, // || true
                            func: () => ShowUI(1)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'Back To Form',
                            link: false, // || true
                            func: () => ShowUI(2)
                        }
                    ]
                )

            }
        }

        if ( mode === 1 )
        {
            if ( ShowSpecifications )
            {
                setShowSpecifications( false );
            }else
            {
                setShowSpecifications( true );

                setShowPrForm( false );
                setShowSpForm( false );

                setData(
                    [
                        {
                            icon: 'las la-money-check-alt',
                            txt: 'Add Specification',
                            link: false, // || true
                            func: () => ShowUI(0)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'All Specifications',
                            link: false, // || true
                            func: () => ShowUI(1)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'Back To Form',
                            link: false, // || true
                            func: () => ShowUI(2)
                        }
                    ]
                )
            }
        }

        if ( mode === 2 )
        {
            if ( ShowPrForm )
            {
                setShowPrForm( false );
            }else
            {
                setShowPrForm( true );
                
                setShowSpForm( false );
                setShowSpecifications( false );
                
                setData(
                    [
                        {
                            icon: 'las la-money-check-alt',
                            txt: 'Add Specification',
                            link: false, // || true
                            func: () => ShowUI(0)
                        },
                        {
                            icon: 'las la-list-alt',
                            txt: 'All Specifications',
                            link: false, // || true
                            func: () => ShowUI(1)
                        }
                    ]
                )
            }
        }

    }

    const RemoveRRItem = ( id ) => {

        setAllSpecifications(
            AllSpecifications.filter(
                ( val, index ) => {
                    return index !== id
                }
            )
        )
        
    }
    
    const ChangeHandler = (e) => {

        const { name, value } = e.target;

        
        let val = {
            ...Specifications,
            [name]: value
        }
        setSpecifications( val );
        
        if ( name === "quantity" )
        {
            setTotal( Specifications.amount * value );        
        }else

        if ( name === "amount" )
        {
            setTotal( Specifications.quantity * value );
        }

    }

    const AddSpecification = ( e ) => {

        e.preventDefault();

        $('.SpecificationForm input[type=checkbox][name=WantQuantity]').prop('checked', false);
        $('.SpecificationForm input[type=checkbox][name=WantQuantity]').prop('required', false);
        $('.SpecificationForm input[type=checkbox][name=WantAmount]').prop('checked', false);
        $('.SpecificationForm input[type=checkbox][name=WantAmount]').prop('required', false);
        $('.df_none').slideUp(0);

        toast.dark('Specification Added', {
            position: 'top-right',
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });

        let val = {
            desc: Specifications.desc,
            quantity: Specifications.quantity,
            amount: Specifications.amount,
            total: Total,
            reason: Specifications.reason
        }

        setAllSpecifications([...AllSpecifications, val]);
        setSpecifications(
            {
                desc: '',
                quantity: 0,
                amount: 0,
                reason: ''
            }
        )

        setTotal(0.00);

    }

    return (
        <>
            <Menu data={ Data } />
            <div className="Employee_Requisition">
                <div className="Employee_Requisition_Grid">
                    {
                        ShowPrForm
                        ?
                            <div className="Purchase_Requisition" style={ { animationDelay: ( 0 + '.' + 1 ).toString() + 's' } }>
                                <div className="Box1">
                                    <form action="">
                                        <h4 className="mb-3 font-weight-bolder">Item Request</h4>
                                        <div className="mb-3">
                                            <p className="mb-2 font-weight-bolder"> Delivery Location: </p>
                                            <input type="text" className="border w-100 form-control" list="deliveryLocations" name="" required minLength="2" />
                                            <datalist id="deliveryLocations">
                                                {
                                                    Locations.map(
                                                        (val, index) => {

                                                            return (
                                                                <option value={val.location_name} key={index}>  </option>
                                                            )

                                                        }
                                                    )
                                                }
                                            </datalist>
                                        </div>
                                        {/* 
                                            <div className="mb-3 d-flex align-items-center">
                                            <input type="checkbox" name="WantAdvanceCash" onChange={ () => ShowADForm( 'Advance Payments' ) } />
                                            <p className="ml-2 mb-0 font-weight-bolder"> Advance Cash</p>
                                            </div> 
                                        */}
                                        <div>
                                            <button className="btn" style={{ fontSize: '12px', backgroundColor: '#474d53', color: 'white', width: '100%' }} >Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        :
                        ShowSpecifications
                        ?
                        <>
                            {    
                            AllSpecifications.length === 0
                            ?
                                <div className="Requisition_Details" style={ { animationDelay: ( 0 + '.' + 1 ).toString() + 's' } }>
                                    <h4 className="font-weight-bolder text-center">No Specifications</h4>
                                </div>
                            :
                                AllSpecifications.map(
                                    ( val, index ) => {

                                        return (
                                            <div className="Requisition_Details" style={ { animationDelay: ( 0 + '.' + index + 1 ).toString() + 's' } }>
                                                <div className="Details_Grid">
                                                    <div>
                                                        <div className="font-weight-bold">ID</div>
                                                        <div>{ index + 1 }</div>
                                                    </div>

                                                    <div>
                                                        <div className="font-weight-bold">Description</div>
                                                        <div>{ val.desc }</div>
                                                    </div>

                                                    {
                                                        val.quantity > 0
                                                        ?
                                                        <div>
                                                            <div className="font-weight-bold">Quantity</div>
                                                            <div>{ val.quantity }</div>
                                                        </div>
                                                        :
                                                        null
                                                    }

                                                    {
                                                        val.amount > 0
                                                        ?
                                                        <div>
                                                            <div className="font-weight-bold">Amount</div>
                                                            <div>{ val.amount }</div>
                                                        </div>
                                                        :
                                                        null
                                                    }

                                                    {
                                                        val.amount > 0 && val.quantity > 0
                                                        ?
                                                        <div>
                                                            <div className="font-weight-bold">Total</div>
                                                            <div>{ val.total }</div>
                                                        </div>
                                                        :
                                                        null
                                                    }
                                                    <div className="d-flex showicon">
                                                        {/* <div onClick={() => ShowEdditNP('New Purchase')}><i className="las la-edit mr-2"></i></div> */}
                                                        <div onClick={() => RemoveRRItem(index,)}><i className="las la-trash-alt"></i></div>
                                                    </div>
                                                </div>
                                            </div>
                                        )

                                    }
                                ) 
                            }
                        </>
                        :
                        <SpecificationForm AddSpecification={ AddSpecification } Total={ Total } Specifications={ Specifications } onChangeHandler={ ChangeHandler } />
                    }
                </div>
            </div>
        </>
    )
}
export default Employee_Requisition;