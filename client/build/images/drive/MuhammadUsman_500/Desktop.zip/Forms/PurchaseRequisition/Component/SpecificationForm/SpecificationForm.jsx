import React, { useEffect } from 'react';

import './SpecificationForm.css';
import $ from 'jquery';

function SpecificationForm ( props ) {

    useEffect(
        () => {

            $('.df_none').slideUp(0);

        }, []
    )

    const ShowInputs = ( e ) => {

        const { name } = e.target;
        
        let input1 = $('.SpecificationForm input[type=checkbox][name=WantQuantity]').prop('checked');
        let input2 = $('.SpecificationForm input[type=checkbox][name=WantAmount]').prop('checked');


        if ( name === 'WantQuantity' )
        {
            if ( input1 )
            {
                $('#QuantityInput').slideDown(500);
                RequiredFields('quantity', true);

                if ( input1 && input2 )
                {
                    $('#TotalOutput').slideDown(500);
                    RequiredFields('quantity', true);
                    RequiredFields('amount', true);
                }

            }else
            {
                $('#QuantityInput').slideUp(500);
                RequiredFields('quantity', false);

                $('#TotalOutput').slideUp(500);
                RequiredFields('quantity', false);
                RequiredFields('amount', false);
            }
        }else

        if ( name === 'WantAmount' )
        {
            if ( input2 )
            {
                $('#AmountInput').slideDown(500);
                RequiredFields('amount', true);

                if ( input1 && input2 )
                {
                    $('#TotalOutput').slideDown(500);
                    RequiredFields('quantity', true);
                    RequiredFields('amount', true);
                }

            }else
            {
                $('#AmountInput').slideUp(500);
                RequiredFields('amount', false);

                $('#TotalOutput').slideUp(500);
                RequiredFields('quantity', false);
                RequiredFields('amount', false);
            }
        }

    }

    const RequiredFields = ( name, condition ) => {

        $('.SpecificationForm .Inputs[name=' + name + ']').prop('required', condition);
        if ( condition )
        {
            $('.SpecificationForm .Inputs[name=' + name + ']').prop('min', 1);
        }else
        {
            $('.SpecificationForm .Inputs[name=' + name + ']').prop('min', 0);
        }

    }

    return (
        <div className='SpecificationForm' style={ { animationDelay: ( 0 + '.' + 1 ).toString() + 's' } }>
            <h4 className="mb-3 font-weight-bolder"> Add Specification </h4>
            <form onSubmit={ props.AddSpecification }>
                    <div className="mb-3">
                        <p className="font-weight-bolder mb-2 ">Description</p>
                        <input className="form-control w-100" value={ props.Specifications.desc } onChange={ props.onChangeHandler } name='desc' minLength="3" required />
                    </div>
                <div className="d-flex align-content-center">
                    <div className="mb-3 d-flex align-items-center w-100">
                        <input type="checkbox" name="WantQuantity" onChange={ ShowInputs } />
                        <p className="ml-2 mb-0 font-weight-bolder">Quantity</p>
                    </div>
                    <div className="mb-3 d-flex align-items-center w-100">
                        <input type="checkbox" name="WantAmount" onChange={ ShowInputs } />
                        <p className="ml-2 mb-0 font-weight-bolder">Price</p>
                    </div>
                </div>
                <div className="mb-3 df_none" id="QuantityInput">
                    <p className="mb-2 font-weight-bolder"> Quantity: </p>
                    <input
                        className="form-control w-100 Inputs"
                        type="number"
                        onChange={ props.onChangeHandler }
                        name='quantity'
                        required={ false }
                        value={ props.Specifications.quantity }
                    />
                </div>
                <div className="mb-3 df_none" id="AmountInput">
                    <p className="mb-2 font-weight-bolder"> Estimated Price <sub>( per unit )</sub>: </p>
                    <input
                        className="form-control w-100 Inputs"
                        type="number"
                        onChange={ props.onChangeHandler }
                        value={ props.Specifications.amount }
                        name='amount'
                        required={ false }
                    />
                </div>
                <div className="mb-3 df_none" id="TotalOutput">
                    <p className="mb-2 font-weight-bolder"> Total: </p>
                    <input
                        className="form-control w-100"
                        type="number"
                        value={ props.Total }
                        name='total'
                    />
                </div>
                <div className="mb-3">
                    <p className="font-weight-bolder mb-2">Reason</p>
                    <textarea
                        className="form-control w-100"
                        id="textarea"
                        onChange={ props.onChangeHandler }
                        value={ props.Specifications.reason }
                        name='reason'
                        required
                        minLength="20"
                    />
                </div>
                    <div className="d-flex justify-content-right">
                        <button type="reset" className="mr-3 btn" style={ {color: 'black'} }>Cancel</button>
                        <button className="btn" type="submit" variant="contained" id="Submit" style={ {backgroundColor: 'black', color: 'white'} }>ADD</button>
                    </div>
                </form>
        </div>
    );

}

export default SpecificationForm;