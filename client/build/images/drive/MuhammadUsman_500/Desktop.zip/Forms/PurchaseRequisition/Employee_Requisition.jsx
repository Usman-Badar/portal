import React, { useEffect, useState } from 'react';
import './Employee_Requisition.css';

import axios from '../../../../../../axios';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import InvoiceBuilder from '../Components/InvoiceBuilder/InvoiceBuilder';

import { useSelector } from 'react-redux';
import $ from 'jquery';
import Menu from '../../../../../UI/Menu/Menu';
import Modal from '../../../../../UI/Modal/Modal';

const Employee_Requisition = () => {

    const EmpData = useSelector((state) => state.EmpAuth.EmployeeData);

    const [Item, setItem] = useState({
        description: "",
        reason: "",
        price: 0,
        quantity: 1,
    });

    const [ReuqestInfo, setReuqestInfo] = useState([]);
    const [Title, setTitle] = useState("ITEM REQUEST");
    const [Items, setItems] = useState([]);
    const [Amount, setAmount] = useState(0.0);
    const [Total, setTotal] = useState(0.0);
    const [EditMode, setEditMode] = useState(false);
    const [Index, setIndex] = useState();
    const [Data, setData] = useState([]);

    const [DefaultInfo, setDefaultInfo] = useState(
        {
            empID: 0,
            image: '',
            name: '',
            designationName: '',
            companyName: '',
            locationName: '',
            email: '',
            cell: 0,
            empCompany: 0,
            empLocation: 0
        }
    );

    const [InvtryEmployees, setInvtryEmployees] = useState([]);
    const [Locations, setLocations] = useState([]);
    const [Companies, setCompanies] = useState([]);

    const [PrevReuqests, setPrevReuqests] = useState([]);

    const [RequestTook, setRequestTook] = useState(
        [
            // {
            //     leaveType: 'Total',
            //     maxLeave: 1000,
            //     val: 10
            // },
            // {
            //     leaveType: 'Total',
            //     maxLeave: 1000,
            //     val: 10
            // },
            // {
            //     leaveType: 'Total',
            //     maxLeave: 1000,
            //     val: 10
            // },
        ]
    );
    const [ModalShow, setModalShow] = useState(false);
    const [ModalShow2, setModalShow2] = useState(false);
    const [ModalContent, setModalContent] = useState(false);

    const [HideReason, setHideReason] = useState( false );
    const [ShowReason, setShowReason] = useState( false );

    useEffect(
        () => {


            if( $(document).width() < 768 )
            {
                setHideReason( true );
            }

            if( $(document).width() < 768 )
            {
                setShowReason( true );
            }
            
            setData(
                [
                    {
                        icon: 'las la-cloud-upload-alt',
                        txt: 'Employee Request',
                        link: false,
                        func: () => ShowLeftGrid()
                    },
                    {
                        icon: 'las la-cloud-upload-alt',
                        txt: 'Item Request',
                        link: false,
                        func: () => ShowRightGrid()
                    }
                ]
            );

            if ($(window).width() < 992) {
                $('.Details_Grid_Right').hide();
             }
             else {
                $('.Details_Grid_Right').show();
             }

            $('.Leave_Application_Details #setDetaults').trigger('click');

            getPrevRequests();

            setInterval(() => {
                getPrevRequests();
            }, 1000);

        }, []

    )

    const getPrevRequests = () => {

        const Data = new FormData();
        Data.append('empID', $('.Leave_Application_Details #setDetaults').html() === '' ? 0 : $('.Leave_Application_Details #setDetaults').html());
        axios.post('/getthatempinvtryrequests', Data).then(
            (res) => {

                setPrevReuqests(res.data);

            }
        ).catch(
            (err) => {

                console.log(err);

            }
        )

    }

    const ChangeEmployee = () => {

        $('.Leave_Application_Details .Leave_Application_Details_Grid .Details_Grid_Left .Leave_Emp_Info .default').toggle(300);
        $('.Leave_Application_Details .Leave_Application_Details_Grid .Details_Grid_Left .Leave_Emp_Info .employees').toggle(300);

    }

    const GetInvtryEmp = (e) => {

        const { name, value } = e.target;

        const Data = new FormData();
        if (name === 'srchInvtryEmp') {

            if (value === '') {

                setInvtryEmployees([]);

            } else {
                Data.append('key', value);
                axios.post('/getinvtryemployees', Data).then(res => {

                    setInvtryEmployees(res.data);

                }).catch(err => {

                    toast.dark(err.toString(), {
                        position: 'top-right',
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });

                });
            }

        }

    }

    const changeCompany = (e) => {

        const Data = new FormData();
        Data.append('company_code', e.target.value)
        axios.post('/getcompanylocations', Data).then(res => {

            setDefaultInfo(
                {
                    ...DefaultInfo,
                    empCompany: e.target.value,
                    empLocation: res.data[0].location_code
                }
            )
            setLocations(res.data);

        }).catch(err => {

            toast.dark(err.toString(), {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

        });

    }

    const setDefaultSettings = (id, image, name, desg, comp, locat, email, cell, company, location) => {

        const Data = new FormData();
        Data.append('company_code', company)
        axios.post('/getcompanylocations', Data).then(res => {

            setDefaultInfo(
                {
                    empID: id,
                    image: image,
                    name: name,
                    designationName: desg,
                    companyName: comp,
                    locationName: locat,
                    email: email,
                    cell: cell,
                    empCompany: company,
                    empLocation: location
                }
            )

            setCompanies(
                [
                    {
                        company_code: company,
                        company_name: comp
                    }
                ]
            );

            setLocations(res.data);

        }).catch(err => {

            toast.dark(err.toString(), {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

        });

    }

    const SelectEmployee = (index) => {

        axios.get('/getallcompanies').then(res => {

            setDefaultInfo(
                {
                    empID: InvtryEmployees[index].emp_id,
                    image: InvtryEmployees[index].emp_image,
                    name: InvtryEmployees[index].name,
                    designationName: InvtryEmployees[index].designation_name,
                    companyName: InvtryEmployees[index].company_name,
                    locationName: InvtryEmployees[index].location_name,
                    email: InvtryEmployees[index].email,
                    cell: InvtryEmployees[index].cell,
                    empCompany: InvtryEmployees[index].company_code,
                    empLocation: InvtryEmployees[index].location_code
                }
            )
            ChangeEmployee();
            setCompanies(res.data);

            const Data = new FormData();
            Data.append('company_code', InvtryEmployees[index].company_code)
            axios.post('/getcompanylocations', Data).then(res => {

                setLocations(res.data);

            }).catch(err => {

                toast.dark(err.toString(), {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });

            });

        }).catch(err => {

            toast.dark(err.toString(), {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

        });

    }

    const changeLocation = (e) => {

        const { name, value } = e.target;

        setDefaultInfo(
            {
                ...DefaultInfo,
                [name]: parseInt(value)
            }
        )

    }

    const onChnageHandler = (e) => {
        const { name, value } = e.target;

        const val = {
            ...Item,
            [name]: value,
        };

        setItem(val);

        if (name === "price") {
            let amount = value * Item.quantity;
            setAmount(amount);
        }

        if (name === "quantity") {
            let amount = value * Item.price;
            setAmount(amount);
        }
    };

    const calculateTotal = () => {

        let cost = 0;
        for (let x = 0; x < Items.length; x++) {
            cost = cost + Items[x].amount;
        }

        setTotal(cost);

    }

    const OnEdit = (index) => {

        setAmount(Items[index].amount);
        setItem({
            description: Items[index].description,
            reason: Items[index].reason,
            price: Items[index].price,
            quantity: Items[index].quantity,
        });
        calculateTotal();
        setEditMode(true);
        setIndex(index);

        if ($(window).width() > 768) {

            $(".InvoiceBuilder .edition").addClass("itemsEdit");
            $(".InvoiceBuilder .data").removeClass("d-none");

            $(".InvoiceBuilder .itemsEdit" + index).removeClass("itemsEdit");

            $(".InvoiceBuilder .itemsData" + index).addClass("d-none");
            
        } else {

            setModalShow2(true);

        }

    };

    const onDelete = (id) => {

        setItems(
            Items.filter((val, index) => {
                return index !== id;
            })
        );

        setTotal(Total - Items[id].amount);
        calculateTotal();
    };

    const AddItem = (e) => {
        calculateTotal();

        var objDiv = document.getElementById("ItemsLIst");
        objDiv.scrollTop = objDiv.scrollHeight;
        if (
            Item.description !== '' &&
            Item.reason !== '' &&
            (
                Item.price !== 0 ||
                Item.quantity !== 0
            ) &&
            e.keyCode === 13
        ) {
            if (!EditMode) {
                let cart = {
                    description: Item.description,
                    reason: Item.reason,
                    price: Item.price,
                    quantity: Item.quantity,
                    amount: Amount,
                };
                setItems([...Items, cart]);

                setAmount(0.0);
                setItem({
                    description: "",
                    reason: "",
                    price: 0,
                    quantity: 1,
                });
                let t = Total;

                t = t + Amount;
                setTotal(t);
            } else {
                let arr = Items;
                let cart = {
                    description: Item.description,
                    reason: Item.reason,
                    price: Item.price,
                    quantity: Item.quantity,
                    amount: Amount,
                };

                setTotal(Total - arr[Index].amount + Amount);

                arr[Index] = cart;
                setItems(arr);

                setAmount(0.0);
                setItem({
                    description: "",
                    reason: "",
                    price: 0,
                    quantity: 1,
                });
                setEditMode(false);
                setIndex();

                $(".InvoiceBuilder .edition").addClass("itemsEdit");
                $(".InvoiceBuilder .data").removeClass("d-none");
            }
        }

        

        if ($(window).width() < 768) {

            setHideReason (true);


        } else {

            setHideReason (false);

        }


    };
    const onSave = () => {

        if (Items.length > 0) {

            setItem({
                description: "",
                reason: "",
                price: 0,
                quantity: 1,
            });

            setItems([]);
            setAmount(0.0);
            setTotal(0.0);
            setEditMode(false);
            setIndex();

            const Data = new FormData();
            Data.append('Specifications', JSON.stringify(Items));
            Data.append('EmpInfo', JSON.stringify(DefaultInfo));
            Data.append('senderInfo', DefaultInfo.empID === EmpData.emp_id ? null : JSON.stringify(EmpData));

            axios.post('/purchaserequision', Data).then(
                () => {

                    toast.dark('Request Submitted', {
                        position: 'top-right',
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });

                    const Data3 = new FormData();
                    Data3.append('access', JSON.stringify([512, 514]));
                    axios.post('/getemployeeaccesslike', Data3).then(
                        (res) => {

                            if (res.data[0]) {
                                for (let x = 0; x < res.data.length; x++) {
                                    const Data2 = new FormData();
                                    Data2.append('eventID', 3);
                                    Data2.append('receiverID', res.data[x].emp_id);
                                    Data2.append('senderID', sessionStorage.getItem('EmpID'));
                                    Data2.append('Title', sessionStorage.getItem('name'));
                                    Data2.append('NotificationBody', sessionStorage.getItem('name') + ' post a new purchase request on the portal');
                                    axios.post('/newnotification', Data2).then(() => {

                                        axios.post('/sendmail', Data2).then(() => {

                                        })
                                    });
                                }
                            }

                        }
                    )


                }
            ).catch(
                (err) => {

                    toast.dark(err.toString(), {
                        position: 'top-right',
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });

                }
            )
        } else {
            toast.dark('Minimum one specification required', {
                position: 'top-right',
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

        }

    };

    const ShowTheDetails = (prID) => {

        const Data = new FormData();
        Data.append('prID', prID);
        axios.post('/getthatrequestfulldetails', Data).then(
            (result) => {

                axios.post('/getrequestspecifications', Data).then(
                    (result2) => {

                        setItems(result2.data);
                        setReuqestInfo(result.data);

                        calculateTotal();
                        var objDiv = document.getElementById("ItemsLIst");
                        if (objDiv !== null) {
                            objDiv.scrollTop = objDiv.scrollHeight;
                        }

                        setLocations(
                            [
                                {
                                    location_name: result.data[0].location_name,
                                    location_code: result.data[0].location_code
                                }
                            ]
                        )

                        let cost = 0;
                        for (let x = 0; x < result2.data.length; x++) {
                            cost = cost + result2.data[x].amount;
                        }

                        setTotal(cost);
                        setTitle("REQUEST DETAILS");

                        setEditMode(true);
                        $('.InvoiceBuilder .abs').addClass('d-none');

                    }
                ).catch(
                    (err) => {

                        console.log(err);

                    }
                )

            }).catch(err => {

                toast.dark(err, {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });;

            });

    }

    const onDeliver = (prID) => {

        setModalContent(
            <div>
                <p>Did you receive your item?</p>
                <form onSubmit={(e) => SendRequestToDeliver(prID, e)}>
                    <textarea name='remarks' className="form-control mb-3" placeholder="Add Remarks" required minLength="10" />
                    <button className="btn btn-sm btn-primary d-block ml-auto px-3">Yes</button>
                </form>
            </div>
        )

        setModalShow(true);

    }

    const SendRequestToDeliver = (prID, e) => {

        e.preventDefault();

        const Data = new FormData();
        Data.append('prID', prID);
        Data.append('remarks', e.target['remarks'].value);
        axios.post('/setprtodeliver', Data).then(
            () => {

                const Data2 = new FormData();
                Data2.append('eventID', 3);
                Data2.append('receiverID', ReuqestInfo[0].handle_by);
                Data2.append('senderID', sessionStorage.getItem('EmpID'));
                Data2.append('Title', sessionStorage.getItem('name'));
                Data2.append('NotificationBody', sessionStorage.getItem('name') + ' has received their items');
                axios.post('/newnotification', Data2).then(() => {

                    axios.post('/sendmail', Data2).then(() => {

                    })
                });
                toast.dark('Item has been delivered', {
                    position: 'top-right',
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });

                setItems([]);
                calculateTotal();
                setModalContent(<></>);
                setModalShow(false);
                setReuqestInfo([]);

                setIndex()
                setEditMode(false)
                setTotal(0.00)
                setAmount(0.00)
                setTitle("ITEM REQUEST");

                setEditMode(false);
                $('.InvoiceBuilder .abs').removeClass('d-none');

            }

        ).catch(
            (err) => {

                console.log(err);

            }
        )

    }

    const ShowHideModal = () => {

        if (ModalShow) {

            setModalShow(false);

        } else {

            setModalShow(true);

        }

    }

    const ShowHideModal2 = () => {

        if (ModalShow2) {

            setModalShow2(false);

        } else {

            setModalShow2(true);
            
        }

    }

    let send = null;
    let delivered = null;

    if (ReuqestInfo[0] === undefined) {
        send = {
            txt: 'Send',
            func: () => onSave(),
            bgColor: 'default',
            color: 'default'
        }
        delivered = null;
    }

    if (ReuqestInfo[0] ? ReuqestInfo[0].status === 'Approved' : null) {

        delivered = {
            txt: 'Delivered',
            func: () => onDeliver(ReuqestInfo[0].pr_id),
            bgColor: '#2067D6',
            color: 'white'
        }
        send = null;

    }

    const hideDetails = () => {

        setItems([]);
        calculateTotal();
        setModalContent(<></>);
        setModalShow(false);
        setReuqestInfo([]);

        setIndex()
        setEditMode(false)
        setTotal(0.00)
        setAmount(0.00)
        setTitle("ITEM REQUEST");

        setEditMode(false);
        $('.InvoiceBuilder .abs').removeClass('d-none');

    }

    const ShowLeftGrid = () => {
        $('.Details_Grid_Left').show();
        $('.Details_Grid_Right').hide();
    }
    const ShowRightGrid = () => {
        $('.Details_Grid_Left').hide();
        $('.Details_Grid_Right').show();
    }


    

    return (
        <>
            <div className="PurchaseRequisition">
                <Menu data={Data} />
                <Modal show={ModalShow} Hide={ShowHideModal} content={ModalContent} />
                <ToastContainer />
                <div className="Leave_Application_Details">
                    <div
                        id="setDetaults"
                        className="d-none"
                        onClick={
                            () => setDefaultSettings(
                                EmpData.emp_id, EmpData.emp_image, EmpData.name,
                                EmpData.designation_name, EmpData.company_name, EmpData.location_name,
                                EmpData.email, EmpData.cell, EmpData.company_code, EmpData.location_code
                            )
                        }
                    >
                        {
                            EmpData.emp_id
                        }
                    </div>
                    <div className="Leave_Application_Details_Grid">
                        <div className="Details_Grid_Left">
                            <div className="Leave_Emp_Info">
                                <div className="default">
                                    <div className="d-flex align-items-center pb-2">
                                        <div>
                                            <img src={'images/employees/' + DefaultInfo.image} alt="DP" className="currntemp" />
                                        </div>
                                        <div className="ml-3 py-2">
                                            <p className="font-weight-bolder mb-0">{DefaultInfo.name}</p>
                                            <p className="mb-0">{DefaultInfo.designationName + ' at ' + DefaultInfo.companyName + ', ' + DefaultInfo.locationName}</p>
                                        </div>
                                    </div>
                                    <div className="d-flex justify-content-between py-2" style={{ fontSize: "13px" }}>
                                        <p className="mb-0">Employee Code</p>
                                        <p className="font-weight-bolder mb-0">{DefaultInfo.empID}</p>
                                    </div>
                                    <div className="d-flex justify-content-between py-2" style={{ fontSize: "13px" }}>
                                        <p className="mb-0">Email</p>
                                        <p className="font-weight-bolder mb-0">{DefaultInfo.email}</p>
                                    </div>
                                    <div className="d-flex justify-content-between py-2" style={{ fontSize: "13px" }}>
                                        <p className="mb-0">Phone Number</p>
                                        <p className="font-weight-bolder mb-0">{DefaultInfo.cell}</p>
                                    </div>
                                </div>
                                {
                                    EmpData.access ? JSON.parse(EmpData.access).includes(510)
                                        ?
                                        <>
                                            <div className="empDropdown d-flex align-items-center" onClick={ChangeEmployee}>
                                                <i className="las la-fill-drip mr-2"></i> <span>Employees</span>
                                            </div>
                                        </>
                                        :
                                        null
                                        :
                                        null
                                }

                                <div className="employees pt-4">

                                    <div className="empSearch">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Enter employee name"
                                            onChange={GetInvtryEmp}
                                            name="srchInvtryEmp"
                                        />
                                        {
                                            InvtryEmployees.length > 0
                                                ?
                                                <div className="dropdown">
                                                    {InvtryEmployees.map(
                                                        (val, index) => {

                                                            return (
                                                                <div className="d-flex align-items-center emps" onClick={() => SelectEmployee(index)}>
                                                                    <div>
                                                                        <img src={'images/employees/' + val.emp_image} alt="DP" />
                                                                    </div>
                                                                    <div className="ml-3 py-2">
                                                                        <p className="font-weight-bolder mb-0">{val.name}</p>
                                                                        <p className="mb-0">{val.designation_name + ' at ' + val.company_name + ', ' + val.location_name}</p>
                                                                    </div>
                                                                </div>
                                                            )

                                                        }
                                                    )}
                                                </div>
                                                :
                                                null
                                        }
                                    </div>

                                </div>
                            </div>
                            <h4>
                                Previous Requests
                            </h4>

                            <div className="allPrevRequets" id="my-node">
                                {
                                    PrevReuqests.length === 0
                                        ?
                                        null
                                        :
                                        PrevReuqests.map(
                                            (val, index) => {
                                                return (
                                                    <>
                                                        <div className="requests" style={{ animationDelay: (0 + '.' + index).toString() + 's' }}>
                                                            <div>

                                                                <div
                                                                    style=
                                                                    {
                                                                        {
                                                                            width: '100%',
                                                                            display: 'grid',
                                                                            gridTemplateColumns: '80fr 20fr',
                                                                            gridGap: '50px'
                                                                        }
                                                                    }
                                                                >
                                                                    <div>
                                                                        <div className="d-flex align-content-center justify-content-between">
                                                                            <div>
                                                                                <p className='mb-0 font-weight-bold'>
                                                                                    Requested By
                                                                                </p>
                                                                                <p className='mb-0'>
                                                                                    {val.name}
                                                                                </p>
                                                                            </div>
                                                                            <div>
                                                                                <p className='mb-0 font-weight-bold'>
                                                                                    Requested For
                                                                                </p>
                                                                                <p className='mb-0'>
                                                                                    {
                                                                                        val.request_by === val.request_for ||
                                                                                            val.request_for === null
                                                                                            ?
                                                                                            'Himself'
                                                                                            :
                                                                                            val.request_for
                                                                                    }
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="d-flex align-content-center justify-content-between">
                                                                            <div>
                                                                                <p className='mb-0 font-weight-bold'>
                                                                                    Requested Date
                                                                                </p>
                                                                                <p className='mb-0'>
                                                                                    {val.request_date ? val.request_date.substring(0, 10) : null}
                                                                                </p>
                                                                            </div>
                                                                            <div>
                                                                                <p className='mb-0 font-weight-bold'>
                                                                                    Approval Date
                                                                                </p>
                                                                                <p className='mb-0'>
                                                                                    {val.approve_date === null ? 'Not Approved' : val.approve_date ? val.approve_date.substring(0, 10) : null}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex flex-column justify-content-between">
                                                                        {
                                                                            val.status === 'Approved'
                                                                                ?
                                                                                <p className='mb-0 status statusa'>
                                                                                    Approved
                                                                                </p>
                                                                                :
                                                                                val.status === 'Rejected'
                                                                                    ?
                                                                                    <p className='mb-0 status statusr'>
                                                                                        Rejected
                                                                                    </p>
                                                                                    :
                                                                                    val.status === 'Waiting For Approval'
                                                                                        ?
                                                                                        <p className='mb-0 status statusp'>
                                                                                            Waiting
                                                                                        </p>
                                                                                        :
                                                                                        val.status === 'Delivered'
                                                                                            ?
                                                                                            <p className='mb-0 status statusa'>
                                                                                                Delivered
                                                                                            </p>
                                                                                            :
                                                                                            <p className='mb-0 status statusp'>
                                                                                                Pending
                                                                                            </p>
                                                                        }
                                                                        <p className='mb-0 status text-center bg-light' onClick={() => ShowTheDetails(val.pr_id)}>
                                                                            View
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </>
                                                )

                                            }
                                        )
                                }
                            </div>

                        </div>
                        <div className="Details_Grid_Right">
                            <div className="Grid_Right1" style={{ animationDelay: (0 + '.' + 1).toString() + 's' }}>
                                <div className="Right2_TopBox mb-3">
                                    {
                                        RequestTook.length === 0
                                            ?
                                            null
                                            :
                                            RequestTook.map(
                                                (value, index) => {

                                                    return (
                                                        <div
                                                            style={{ animationDelay: (0 + '.' + index).toString() + 's' }}
                                                            key={index}
                                                            className={"TopBox_Leave TopBox_Leave" + index}
                                                        >
                                                            <div>
                                                                <p>{value.maxLeave + '/' + value.val}</p>
                                                                <p>{value.leaveType}</p>
                                                            </div>
                                                        </div>
                                                    )

                                                }
                                            )
                                    }
                                </div>
                                <div className="Purchase_Requisition" style={{ animationDelay: (0 + '.' + 1).toString() + 's' }}>
                                    <div className="Box1">
                                        {
                                            ReuqestInfo[0]
                                                ?
                                                <i className="las la-times" onClick={hideDetails}></i>
                                                :
                                                null
                                        }
                                        <InvoiceBuilder
                                            DefaultInfo={DefaultInfo}
                                            EmpData={EmpData}
                                            Locations={Locations}
                                            Companies={Companies}
                                            changeLocation={changeLocation}
                                            title={Title}
                                            ShowTotal={false}
                                            onChnageHandler={onChnageHandler}
                                            onDelete={onDelete}
                                            OnEdit={OnEdit}
                                            AddItem={AddItem}
                                            onSave={onSave}
                                            Items={Items}
                                            Amount={Amount}
                                            Item={Item}
                                            EditMode={EditMode}
                                            Total={Total}
                                            Btns={
                                                [
                                                    send,
                                                    delivered
                                                ]
                                            }
                                            changeCompany={changeCompany}
                                            ShowHideModal={ ShowHideModal2 }
                                            ModalShow={ ModalShow2 }
                                            HideReason={ HideReason }
                                            ShowReason={ ShowReason }
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Employee_Requisition;