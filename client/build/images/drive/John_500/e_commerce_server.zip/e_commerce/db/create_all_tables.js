const mysql = require('mysql');
const express = require('express');
const router = express.Router();

function MakeConnection ()
{
    const db = mysql.createPool( 
        {
            host: process.env.DB_HOST,
            port : process.env.DB_PORT,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            multipleStatements: true,
            supportBigNumbers: true,
            connectionLimit: 300
        }
    );

    return db;
}

function CreateAllTables ( db_name )
{
    const db = mysql.createPool( 
        {
            host: process.env.DB_HOST,
            port : process.env.DB_PORT,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            multipleStatements: true,
            supportBigNumbers: true,
            connectionLimit: 300
        }
    );

    let q = db.query(
        "CREATE DATABASE " + db_name + ";" +
        "CREATE TABLE `" + db_name + "`.`tbl_users` ( `user_id` INT NOT NULL AUTO_INCREMENT ,  `login_id` TEXT NOT NULL ,  `password` TEXT NOT NULL ,  `email` TEXT NOT NULL ,    PRIMARY KEY  (`user_id`)) ENGINE = InnoDB;",
        ( err, result ) => {

            console.log( q.sql );
            if ( err )
            {
                console.log( 'err', err );
            }else
            {
                console.log( 'result', result );
            }

        }
    )
}

const crypt = (salt, text) => {

    const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
    const byteHex = (n) => ("0" + Number(n).toString(16)).substr(-2);
    const applySaltToChar = (code) => textToChars(salt).reduce((a, b) => a ^ b, code);
    
    return text
        .split("")
        .map(textToChars)
        .map(applySaltToChar)
        .map(byteHex)
        .join("");

};



module.exports = {
    router: router,
    CreateAllTables: ( db_name ) => CreateAllTables( db_name ),
    MakeConnection: () => MakeConnection()
};