const mysql = require('mysql');
const express = require('express');
const router = express.Router();
const fs = require('fs');
const CreateAllTables = require('./create_all_tables').CreateAllTables;

router.get(
    '/connection/testing',
    ( req, res ) => {

        // CHECKING FOR THE DATABASE HOST CONNECTION
        const checkForDBHostConnection = mysql.createConnection( 
            {
                host: process.env.DB_HOST,
                port : process.env.DB_PORT,
                user: process.env.DB_USER,
                password: process.env.DB_PASSWORD,
                multipleStatements: true,
                supportBigNumbers: true,
                connectionLimit: 300
            }
        );

        // CONNECT HOST
        checkForDBHostConnection.connect(
            ( err ) => {
                if ( err )
                {
                    console.log( err.sqlMessage );
                    res.send(err);
                    res.end();
                }else
                {
                    console.log( "DATABASE SERVER CONNECTED" );

                    // CHECKING FOR THE DATABASE CONNECTION
                    const checkForDBConnection = mysql.createConnection( 
                        {
                            host: process.env.DB_HOST,
                            port : process.env.DB_PORT,
                            user: process.env.DB_USER,
                            password: process.env.DB_PASSWORD,
                            database: process.env.DB_NAME,
                            multipleStatements: true,
                            supportBigNumbers: true,
                            connectionLimit: 300
                        }
                    );

                    // CONNECT DATABASE
                    checkForDBConnection.connect(
                        ( err ) => {
                            if ( err )
                            {
                                console.log( err.sqlMessage );
                                res.send(err);
                                res.end();
                            }else
                            {
                                console.log( "DATABASE EXISTS" );

                                // CHECKING FOR THE TABLES
                                checkForDBConnection.query(
                                    "SELECT user_id FROM tbl_users",
                                    ( err ) => {
                        
                                        if ( err )
                                        {
                                            console.log( err.sqlMessage );
                                            res.send(err);
                                            res.end();
                                        }else
                                        {
                                            console.log( "TABLES EXISTS" );
                                            res.send("TABLES EXISTS");
                                            res.end();
                                        }
                        
                                    }
                                )
                            }
                        }
                    )
                }
            }
        )

    }
)

router.post(
    '/connection/make',
    ( req, res ) => {

        const { db_name, db_user, db_password, db_host } = req.body;

        const envFileContent = ` \
        DB_HOST=${ db_host }\n \
        DB_PORT=${ 3306 }\n \
        DB_USER=${ db_user }\n \
        DB_PASSWORD=${ db_password }\n \
        DB_NAME=${ db_name }\n \
        \n \
        SERVER_PORT=8888 \
        `;

        fs.writeFile(
            '.env', envFileContent, 'utf-8',
            ( err ) => {

                if ( err )
                {
                    console.error( err );
                    console.log("ERROR IN CREATING .ENV FILE");
                    res.send( err );
                    res.end();
                }else
                {
                    console.log(".ENV FILE HAS CREATED");
                    CreateAllTables( db_name );

                    res.send("TABLES CREATED");
                    res.end();
                }

            }
        )

    }
)

module.exports = router;