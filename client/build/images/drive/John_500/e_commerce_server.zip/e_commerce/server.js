const express = require('express');
const app = express();
const compression = require('compression');
const cors = require('cors');

app.use( cors() );
app.use( express.json() );
app.use( compression() );
require('dotenv').config();

app.use( require('./db/connection') );

app.listen(
    process.env.SERVER_PORT, 
    () => {

        console.log("**************************************************");
        console.log('\x1b[34m%s\x1b[0m', `Server run on localhost:${ process.env.SERVER_PORT } with id = ${ process.pid }`);
        console.log("**************************************************");

    }
);