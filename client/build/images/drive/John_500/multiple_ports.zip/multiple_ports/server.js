const express = require('express');
const app = express();

app.use(express.json());
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

app.use((req, res, next) => {   

    req.port = req.socket.localPort;
    next();
});

app.get(
    '/',
    ( req, res ) => {

        if ( req.port === 5000 )
        {
            res.render('E:/IT/HTML/demo1/');
        }else
        if ( req.port === 3000 )
        {
            res.render('E:/IT/HTML/demo2/');
        }
        res.end();

    }
)

// app.use(require('./forPort3000'));
// app.use(require('./forPort5000'));

app.listen(3000, () => console.log('listening on 3000'));
app.listen(5000, () => console.log('listening on 5000'));