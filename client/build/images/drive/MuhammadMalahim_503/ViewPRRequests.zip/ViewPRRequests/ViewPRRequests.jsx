import React, { useState, useEffect } from "react";
import './ViewPRRequests.css';

import axios from "../../../../../../axios";

// React Redux Packages
import { useSelector } from 'react-redux';

// import { Chart } from "react-chartjs-2/dist/chart";

const ViewPRRequests = () => {

    const [ViewRequest, setViewRequest] = useState([])


    // Current Employee Data
    const EmpData = useSelector((state) => state.EmpAuth.EmployeeData);

    useEffect(
        () => {

            AllPr();

        }, []
    )

    const AllPr = () => {


        let val = {
            emp_id: EmpData.emp_id,
            access: EmpData.access
        }
        axios.post('/getallpr', { myData: JSON.stringify(val) }).then(response => {

            console.log(response.data);
            setViewRequest(response.data);

        }).catch(error => {

            console.log(error);

        });

    }

    // const ctx = document.getElementById('myChart').getContext('2d');
    // const myChart = new Chart(ctx, {
    //     type: 'bar',
    //     data: {
    //         labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    //         datasets: [{
    //             label: '# of Votes',
    //             data: [12, 19, 3, 5, 2, 3],
    //             backgroundColor: [
    //                 'rgba(255, 99, 132, 0.2)',
    //                 'rgba(54, 162, 235, 0.2)',
    //                 'rgba(255, 206, 86, 0.2)',
    //                 'rgba(75, 192, 192, 0.2)',
    //                 'rgba(153, 102, 255, 0.2)',
    //                 'rgba(255, 159, 64, 0.2)'
    //             ],
    //             borderColor: [
    //                 'rgba(255, 99, 132, 1)',
    //                 'rgba(54, 162, 235, 1)',
    //                 'rgba(255, 206, 86, 1)',
    //                 'rgba(75, 192, 192, 1)',
    //                 'rgba(153, 102, 255, 1)',
    //                 'rgba(255, 159, 64, 1)'
    //             ],
    //             borderWidth: 1
    //         }]
    //     },
    //     options: {
    //         scales: {
    //             y: {
    //                 beginAtZero: true
    //             }
    //         }
    //     }
    // });

    return (
        <>
            <div className="ViewPrRequests">
                <div className="SearchnFilterDiv">
                    <div className="searchdiv">
                        <div><i class="las la-search"></i></div>
                        <input type="search" className="form-control" />
                    </div>
                    <div className="filterdiv">
                        <div>
                            <select name="" id="" className="form-control">
                                <option value="Company">Company</option>
                                <option value="Company">Seatech</option>
                                <option value="Company">QFS</option>
                                <option value="Company">SBl</option>
                            </select>
                        </div>
                        <div>
                            <select name="" id="" className="form-control">
                                <option value="Location">Location</option>
                                <option value="Location">Headoffice</option>
                            </select>
                        </div>
                        <div>
                            <select name="" id="" className="form-control">
                                <option value="Company">Company</option>
                                <option value="Company">Seatech</option>
                                <option value="Company">QFS</option>
                                <option value="Company">SBl</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div className="ViewPrRequests_grid">
                    <div className="ViewPrRequests_Left">
                        {
                            ViewRequest.map(
                                (val, index) => {

                                    const d = new Date(val.request_date);

                                    return (
                                        <>
                                            <div className="ViewPrRequests_div">
                                                <div className="d-flex align-items-center justify-content-between">
                                                    <div className="d-flex align-items-center w-75">
                                                        <img src={'images/employees/' + val.emp_image} alt="" />
                                                        <div>
                                                            <p className="font-weight-bolder"> {val.name} </p>
                                                            <p> {val.designation_name + ' in ' + val.department_name + ' Department, ' + val.company_name} </p>
                                                        </div>
                                                    </div>
                                                    <div className="w-25">
                                                        <p className="font-weight-bolder">Total</p>
                                                        <p> Rs {val.total.toLocaleString('en-US')}</p>
                                                    </div>
                                                </div>
                                                <div className="py-3">
                                                    <div className="d-flex justify-content-between">
                                                        <div>
                                                            <p className="font-weight-bolder">Date</p>
                                                            <p>{d.toDateString()}</p>
                                                        </div>
                                                        <div>
                                                            <p className="font-weight-bolder">Status</p>
                                                            <p>{val.status}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="d-flex align-items-center">
                                                    <i class="las la-map-marker-alt"></i>
                                                    <div>
                                                        <p className="font-weight-bolder">{val.company_name}</p>
                                                        <p>{val.location_name}</p>
                                                    </div>
                                                </div>
                                                <div className="ViewPrRequests_button">
                                                    <button className="btn">Decline</button>
                                                    <button className="btn">Accept</button>
                                                </div>
                                            </div>
                                        </>
                                    )
                                }
                            )
                        }
                    </div>
                    <div className="ViewPrRequests_Right">
                        <div>
                            <canvas id="myChart" width="400" height="400"></canvas>
                        </div>
                        <div></div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default ViewPRRequests;