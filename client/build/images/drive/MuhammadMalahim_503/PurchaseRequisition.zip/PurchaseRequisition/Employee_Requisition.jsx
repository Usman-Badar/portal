import React, { useEffect, useState } from "react";
import './Employee_Requisition.css';
import { useSelector } from 'react-redux';
import { Route, Link } from 'react-router-dom';

import axios from "../../../../../../axios";
import $ from 'jquery';
import Form from "./Form/Form";
import PreviousRequest from "./PreviousRequest/PreviousRequest";

import Modal from '../../../../../UI/Modal/Modal';

import Menu from "../../../../../UI/Menu/Menu";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Employee_Requisition = () => {

    const Data = useSelector((state) => state.EmpAuth.EmployeeData); // CURRENT EMPLOYEE DATA

    const [List, setList] = useState([]);
    const [Employees, setEmployees] = useState([]);

    const [ModalContent, setModalContent] = useState(<></>);
    const [ModalShow, setModalShow] = useState(false);

    const [MenuData, setMenuData] = useState([]);
    
    const [ViewRequest, setViewRequest] = useState([])

    const [Companies, setCompanies] = useState([]);
    const [Locations, setLocations] = useState([]);
    const [RequestingPerson, setRequestingPerson] = useState(
        {
            emp_id: 0,
            name: '',
            company: {
                company_code: 0,
                company_name: ''
            },
            location: {
                location_code: 0,
                location_name: ''
            }
        }
    );

    const [Items, setItems] = useState([]);
    const [Amount, setAmount] = useState(0.0);
    const [Total, setTotal] = useState(0.0);
    const [Index, setIndex] = useState();

    const [EditMode, setEditMode] = useState(false);

    const [Item, setItem] = useState({
        description: "",
        reason: "",
        price: 0,
        quantity: 1,
    });

    useEffect(
        () => {

            setList(
                [
                    {
                        pr_company_name: "QFS",
                        location_name: "Headoffice",
                        pr_id: "265652315",
                        sender_name: 'muhammad malahim',
                        approve_emp_name: 'Antash'
                    }
                ]
            )
            if (Data.company_code) {

                GetCompanyLocations(Data.company_code);
            }
            $('.PurchaseRequisition').show();
            $('.Discussion').hide(0);

            setMenuData(
                [
                    {
                        icon: 'las la-hand-holding-usd',
                        txt: 'Purchase Requisition',
                        link: true,
                        href: "/purchaserequisition/view=form"
                    },
                    {
                        icon: 'las la-comments',
                        txt: 'Discussion',
                        link: true,
                        href: "/purchaserequisition/view=form"
                    },
                    {
                        icon: 'las la-street-view',
                        txt: 'Select Employee',
                        link: false,
                        func: () => HideModelFunction()
                    }
                ]
            )

            AllPr();


        }, [Data]
    )

    const AllPr = () => {


        let val = {
            emp_id: Data.emp_id,
            access: Data.access
        }
        axios.post('/getallpr', { myData: JSON.stringify(val) }).then(response => {

            console.log(response.data);
            setViewRequest(response.data);

        }).catch(error => {

            console.log(error);

        });

    }

    const AddItem = (e) => {
        if (
            Item.description !== ''
            &&
            Item.reason !== ''
            &&
            Item.quantity > 0
            &&
            e.keyCode === 13
        ) {

            if (Item.reason.length < 20) {

                let val = $(".err_reason").val();

                let i = 0;
                let txt = "Reason must contain 20 characters minimum!!!";
                let speed = 50;
                val = '';

                function typeWriter() {
                    if (i < txt.length) {
                        val += txt.charAt(i);
                        $(".err_reason").html(val);
                        i++;
                        setTimeout(typeWriter, speed);
                    }
                }

                typeWriter();

                setTimeout(() => {
                    $(".err_reason").html('');
                }, 5000);

            } else {

                if (!EditMode) {
                    let cart = {
                        description: Item.description,
                        reason: Item.reason,
                        price: Item.price,
                        quantity: Item.quantity,
                        amount: Amount,
                    };
                    setItems([...Items, cart]);

                    setAmount(0.0);
                    setItem({
                        description: "",
                        reason: "",
                        price: 0,
                        quantity: 1,
                    });
                    let t = Total;

                    t = t + Amount;
                    setTotal(t);

                    var objDiv = document.getElementById("ItemsLIst");
                    if (objDiv !== null) {
                        objDiv.scrollTop = objDiv.scrollHeight;
                    }

                } else {
                    let arr = Items;
                    let cart = {};
                    if (Item.id) {
                        cart = {
                            id: Item.id,
                            pr_id: Item.pr_id,
                            description: Item.description,
                            reason: Item.reason,
                            price: Item.price,
                            quantity: Item.quantity,
                            amount: Amount,
                        };
                    } else {
                        cart = {
                            description: Item.description,
                            reason: Item.reason,
                            price: Item.price,
                            quantity: Item.quantity,
                            amount: Amount,
                        };
                    }
                    setTotal(Total - arr[Index].amount + Amount);

                    arr[Index] = cart;
                    setItems(arr);

                    setAmount(0.0);
                    setItem({
                        description: "",
                        reason: "",
                        price: 0,
                        quantity: 1,
                    });
                    setIndex();
                    setEditMode(false);
                    $(".PR_printUI .PR_printUI_Middle .PR_printUI_Grid.MyItems").removeClass("d-none");
                }
            }

        }

    };

    const onChnageHandler = (e) => {
        const { name, value } = e.target;

        const val = {
            ...Item,
            [name]: value,
        };

        setItem(val);

        if (name === "price") {
            let amount = value * Item.quantity;
            setAmount(amount);
        }

        if (name === "quantity") {
            let amount = value * Item.price;
            setAmount(amount);
        }
    };

    const onCompanyChange = (company_code) => {

        axios.post('/getcompanylocations',
            {
                company_code: company_code ? company_code : Data.company_code
            }
        ).then(res => {

            setLocations(res.data);
            let Company = Companies.filter(
                (val) => {

                    return val.company_code === parseInt(company_code)

                }
            )

            setRequestingPerson(
                {
                    ...RequestingPerson,
                    company: {
                        company_code: Company[0].company_code,
                        company_name: Company[0].company_name
                    }
                }
            );

        }).catch(err => {

            console.log(err);

        });

    }

    const onlocationChange = (company_code) => {

        axios.post('/getcompanylocations',
            {
                company_code: company_code ? company_code : Data.company_code
            }
        ).then(res => {

            setLocations(res.data);
            let Company = Companies.filter(
                (val) => {

                    return val.company_code === parseInt(company_code)

                }
            )

            setRequestingPerson(
                {
                    ...RequestingPerson,
                    company: {
                        company_code: Company[0].company_code,
                        company_name: Company[0].company_name
                    }
                }
            );

        }).catch(err => {

            console.log(err);

        });

    }

    const GetCompanyLocations = (company_code) => {

        axios.post('/getcompanylocations',
            {
                company_code: company_code ? company_code : Data.company_code
            }
        ).then(res => {

            setCompanies(
                [
                    {
                        company_code: Data.company_code,
                        company_name: Data.company_name
                    }
                ]
            )

            setRequestingPerson(
                {
                    emp_id: Data.emp_id,
                    name: Data.name,
                    company: {
                        company_code: Data.company_code,
                        company_name: Data.company_name
                    },
                    location: {
                        location_code: Data.location_code,
                        location_name: Data.location_name
                    }
                }
            )

            setLocations(res.data);

        }).catch(err => {

            console.log(err);

        });

    }

    const Submitform = () => {

        if (Items.length > 0) {

            const Data1 = new FormData();
            Data1.append('Specifications', JSON.stringify(Items));
            Data1.append('EmpInfo', JSON.stringify(RequestingPerson));
            Data1.append('senderInfo', RequestingPerson.emp_id === Data.emp_id ? null : JSON.stringify(Data));

            axios.post('/purchaserequision', Data1).then(
                () => {

                    const Data3 = new FormData();
                    Data3.append('access', JSON.stringify([512, 514]));
                    axios.post('/getemployeeaccesslike', Data3).then(
                        (res) => {

                            if (res.data[0]) {
                                for (let x = 0; x < res.data.length; x++) {

                                    const Data2 = new FormData();
                                    Data2.append('eventID', 3);
                                    Data2.append('receiverID', res.data[x].emp_id);
                                    Data2.append('senderID', sessionStorage.getItem('EmpID'));
                                    Data2.append('Title', sessionStorage.getItem('name'));
                                    Data2.append('NotificationBody', sessionStorage.getItem('name') + ' post a new purchase request on the portal');
                                    axios.post('/newnotification', Data2).then(() => {

                                        axios.post('/sendmail', Data2).then(() => {

                                            // GetCompanyLocations(Data.company_code);
                                            alert("Your form submited")

                                        })
                                    });

                                }
                            }

                        }
                    )


                }
            ).catch(
                (err) => {

                    console.log(err);

                }
            )

        } else {

            alert("Your form not submited")

        }
    }

    const SearchEmployees = (e) => {

        const { value } = e.target;

        const Data = new FormData();
        if (value === '') {

            setEmployees([]);

        } else {

            Data.append('key', value);
            axios.post('/getinvtryemployees', Data).then(res => {

                setEmployees(res.data);

            }).catch(err => {

                ShowNotification(err);

            });

        }

    }

    const HideModelFunction = () => {

        setModalShow(!ModalShow);

    }

    // if employee is been selected
    const EmployeeSelected = (index) => {

        let employee = Employees[index];
        axios.get('/getallcompanies').then(res => { //get all companies

            const Data = new FormData();
            Data.append('company_code', employee.company_code)
            axios.post('/getcompanylocations', Data).then(response => { // get all locations regarding to company code

                // set modal to hide/show
                HideModelFunction();
                // set companies
                setCompanies(res.data);
                // set locations
                setLocations(response.data);

                // set data to request summary
                setRequestingPerson(
                    {
                        emp_id: employee.emp_id,
                        name: employee.name,
                        company: {
                            company_code: employee.company_code,
                            company_name: employee.company_name
                        },
                        location: {
                            location_code: employee.location_code,
                            location_name: employee.location_name
                        }
                    }
                );

            }).catch(err => {

                ShowNotification(err);

            });

        }).catch(err => {

            ShowNotification(err);

        });

    }

    // popup the toast
    const ShowNotification = (note) => {

        toast.dark(note.toString(), {
            position: 'top-right',
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });

    }

    const OnEdit = (index) => {
        setEditMode(true);
        setIndex(index);

        setAmount(Items[index].amount);
        setItem({
            description: Items[index].description,
            reason: Items[index].reason,
            price: Items[index].price,
            quantity: Items[index].quantity,
        });

        $(".PR_printUI #Item" + index).toggleClass("d-none");
    };

    const onDelete = (id) => {

        setItems(
            Items.filter((val, index) => {
                return index !== id;
            })
        );

        setTotal(Total - Items[id].amount);
    };
    return (
        <>
            <Menu data={MenuData} />
            <ToastContainer />
            <Modal show={ModalShow} Hide={HideModelFunction} content={
                <div className="PREmployeesList">
                    <input type="search" placeholder="Search Employee Name" className="form-control" name="empNameSearch" onChange={SearchEmployees} />
                    <div className="list">

                        {
                            Employees.length > 0
                                ?
                                Employees.map(
                                    (val, index) => {
                                        return (

                                            <div
                                                className={"d-flex align-content-center mt-2 employee" + index}
                                                key={index}
                                                style={
                                                    {
                                                        cursor: 'pointer',
                                                        transition: '.5s'
                                                    }
                                                }
                                                onMouseOver={() => $('.PREmployeesList .employee' + index).css('background-color', '#ECF0F5')}
                                                onMouseOut={() => $('.PREmployeesList .employee' + index).css('background-color', 'white')}
                                                onClick={() => EmployeeSelected(index)}
                                            >

                                                <div className="mr-2">
                                                    <img src={'images/employees/' + val.emp_image} className="rounded-circle" width="50" height="50" alt="emp img" />
                                                </div>
                                                <div>
                                                    <p className="font-weight-bold mb-0">{val.name}</p>
                                                    <p className="mb-0">{val.designation_name} in {val.department_name} Dept. {val.company_name}, {val.location_name}</p>
                                                </div>

                                            </div>

                                        )
                                    }
                                )
                                :
                                <h6 className="text-center mt-3">No Employee Found</h6>
                        }

                    </div>
                </div>
            } />
            <div className="Employee_Requisition">
                <div>
                <div className="ViewPrRequests_Left">
                        {
                            ViewRequest.map(
                                (val, index) => {

                                    const d = new Date(val.request_date);

                                    return (
                                        <>
                                            <div className="ViewPrRequests_div">
                                                <div className="d-flex align-items-center justify-content-between">
                                                    <div className="d-flex align-items-center w-75">
                                                        <img src={'images/employees/' + val.emp_image} alt="" />
                                                        <div>
                                                            <p className="font-weight-bolder"> {val.name} </p>
                                                            <p> {val.designation_name + ' in ' + val.department_name + ' Department, ' + val.company_name} </p>
                                                        </div>
                                                    </div>
                                                    <div className="w-25">
                                                        <p className="font-weight-bolder">Total</p>
                                                        <p> Rs {val.total.toLocaleString('en-US')}</p>
                                                    </div>
                                                </div>
                                                <div className="py-3">
                                                    <div className="d-flex justify-content-between">
                                                        <div>
                                                            <p className="font-weight-bolder">Date</p>
                                                            <p>{d.toDateString()}</p>
                                                        </div>
                                                        <div>
                                                            <p className="font-weight-bolder">Status</p>
                                                            <p>{val.status}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="d-flex align-items-center">
                                                    <i class="las la-map-marker-alt"></i>
                                                    <div>
                                                        <p className="font-weight-bolder">{val.company_name}</p>
                                                        <p>{val.location_name}</p>
                                                    </div>
                                                </div>
                                                <div className="ViewPrRequests_button">
                                                    <Link to={ "/purchaserequisition/view=previousrequests/" + val.pr_id }>
                                                        <button className="btn">View</button>
                                                    </Link>
                                                </div>
                                            </div>
                                        </>
                                    )
                                }
                            )
                        }
                    </div>
                </div>
                <div className="Employee_Requisition_Left">

                    <Route
                        exact
                        path='/purchaserequisition/view=form'
                        render={  
                            () =>
                                <Form
                                    List={List}
                                    Items={Items}
                                    Item={Item}
                                    Total={Total}
                                    Data={Data}
                                    Amount={Amount}
                                    Companies={Companies}
                                    Locations={Locations}
                                    onChnageHandler={onChnageHandler}
                                    onCompanyChange={onCompanyChange}
                                    onlocationChange={onlocationChange}
                                    AddItem={AddItem}
                                    OnEdit={OnEdit}
                                    onDelete={onDelete}
                                />
                        }
                    />

                    <Route
                        exact
                        path='/purchaserequisition/view=previousrequests/:pr_id'
                        render={
                            () =>
                                <PreviousRequest
                                />
                        }
                    />

                    <Route
                        exact
                        path='/purchaserequisition/view=discussion/:pr_id'
                        render={
                            () =>
                                <PreviousRequest
                                />
                        }
                    />

                </div>
            </div>
            <div className="Employee_Requisition_Menu">
                <div className="Employee_Requisition_Right">
                    <Link to="/purchaserequisition">
                        <div className="RightButtonDiv">
                            <div className="Box">
                                <div className="circle"><i className="las la-hand-holding-usd"></i></div>
                            </div>
                            <p>Purchase Requisition</p>
                        </div>
                    </Link>
                    <Link to="/purchaserequisition">
                        <div className="RightButtonDiv">
                            <div className="Box">
                                <div className="circle"><i class="las la-comments"></i></div>
                            </div>
                            <p>Discussion</p>
                        </div>
                    </Link>
                    <Link to='/purchaserequisition/previousrequests/1'>
                        <div className="RightButtonDiv">
                            <div className="Box">
                                <div className="circle"><i className="las la-history"></i></div>
                            </div>
                            <p>Previous Requests</p>
                        </div>
                    </Link>
                    <div className="RightButtonDiv" onClick={ HideModelFunction }>
                        <div className="Box">
                            <div className="circle"><i className="las la-street-view"></i></div>
                        </div>
                        <p>Select Employee</p>
                    </div>
                    <div className="Button" onClick={Submitform}>
                        <button className="btn btn-primary"> Submit </button>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Employee_Requisition;